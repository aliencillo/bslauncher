plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.minimal.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.minimal.launcher"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
