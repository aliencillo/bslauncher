package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.pm.ApplicationInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bslauncher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var batteryView: TextView
    private var apps: List<AppEntry> = emptyList()
    private var batteryPercent = 0
    private var isCharging = false
    private var searchVisible = false
    private var downX = 0f
    private var downY = 0f
    private var gestureHandled = false
    private var gestureStarted = false

    private data class AppEntry(val label: String, val packageName: String)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPercent = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (::batteryView.isInitialized) updateBatteryText()
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                gestureHandled = false; gestureStarted = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (!gestureHandled && abs(dx) > dp(42f) && abs(dx) > abs(dy) * 1.35f) {
                    gestureStarted = true
                    if ((dx < 0 && !searchVisible) || (dx > 0 && searchVisible)) {
                        gestureHandled = true
                        if (dx < 0) openSearch() else closeSearch()
                    }
                }
                if (gestureHandled) return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (gestureHandled) { gestureHandled = false; return true }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars()
        loadApps()
        buildScreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        updateInfo()
        window.decorView.post(object : Runnable {
            override fun run() {
                if (isFinishing) return
                updateInfo()
                window.decorView.postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun prefColor(key: String, fallback: Int) = prefs.getInt(key, fallback)

    private fun applySystemBars() {
        if (prefs.getBoolean("hideStatus", true)) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
        window.statusBarColor = prefColor("bg", Color.BLACK)
        window.navigationBarColor = prefColor("bg", Color.BLACK)
        window.decorView.systemUiVisibility = 0
    }

    private fun loadApps() {
        val pm = packageManager
        apps = pm.getInstalledApplications(0).mapNotNull { info ->
            if (info.packageName == packageName) return@mapNotNull null
            val launch = pm.getLaunchIntentForPackage(info.packageName) ?: return@mapNotNull null
            AppEntry(pm.getApplicationLabel(info).toString(), info.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    private fun makeText(value: String, size: Float, color: Int = prefColor("text", Color.WHITE)): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = Typeface.create("sans-serif", if (prefs.getBoolean("bold", false)) Typeface.BOLD else Typeface.NORMAL)
            includeFontPadding = false
        }

    private fun buildScreen() {
        applySystemBars()
        val bg = prefColor("bg", Color.BLACK)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            val margin = prefs.getInt("margin", 20)
            setPadding(dp(margin.toFloat()), dp(12f), dp((margin / 2).toFloat()), dp(8f))
        }

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, -1, prefs.getInt("columnWidth", 74).toFloat())
        }

        search = EditText(this).apply {
            hint = "Buscar aplicaciones"
            setHintTextColor(Color.GRAY)
            setTextColor(prefColor("text", Color.WHITE))
            textSize = 17f
            setSingleLine(true)
            isFocusableInTouchMode = true
            background = null
            setPadding(0, dp(8f), dp(8f), dp(8f))
            visibility = if (searchVisible) View.VISIBLE else View.GONE
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        left.addView(search, LinearLayout.LayoutParams(-1, dp(48f)))

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            isFillViewport = true
        }
        appList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        scroll.addView(appList, android.widget.FrameLayout.LayoutParams(-1, -2))
        left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (prefs.getInt("rotation", 90) == 0) Gravity.TOP or Gravity.START else Gravity.CENTER
        }
        clockView = makeText("00:00", prefs.getFloat("clockSize", 30f)).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER }
        dateView = makeText("01/01 LU", prefs.getFloat("dateSize", 12f)).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER }
        batteryView = makeText("--%", prefs.getFloat("batterySize", 12f)).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER }

        val layoutMode = prefs.getInt("rotation", 90)
        val infoContent = LinearLayout(this).apply {
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = if (layoutMode == 0) Gravity.START or Gravity.CENTER_VERTICAL else Gravity.CENTER
        }
        if (prefs.getBoolean("showClock", true)) infoContent.addView(clockView, spacedParams(layoutMode == 0))
        if (prefs.getBoolean("showDate", true)) infoContent.addView(dateView, spacedParams(layoutMode == 0))
        if (prefs.getBoolean("showBattery", true)) infoContent.addView(batteryView, spacedParams(layoutMode == 0))
        infoContent.rotation = if (layoutMode == 270) 180f else 0f
        info.addView(infoContent)
        info.setOnLongClickListener { showSettings(); true }
        // Permite desplazar el mismo listado deslizando sobre la columna derecha.
        var infoTouchStartY = 0f
        var infoTouchLastY = 0f
        var infoScrollActive = false
        val touchSlop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        info.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    infoTouchStartY = event.y
                    infoTouchLastY = event.y
                    infoScrollActive = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!infoScrollActive && abs(event.y - infoTouchStartY) > touchSlop) {
                        infoScrollActive = true
                    }
                    if (infoScrollActive) {
                        val delta = (infoTouchLastY - event.y).toInt()
                        scroll.scrollBy(0, delta)
                        infoTouchLastY = event.y
                    }
                    infoScrollActive
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val consumed = infoScrollActive
                    infoScrollActive = false
                    consumed
                }
                else -> infoScrollActive
            }
        }
        if (layoutMode == 0) {
            // Tercera opción: bloque informativo arriba, antes de los nombres de aplicaciones.
            root.addView(info, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18f) })
            left.layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            body.addView(left)
        } else {
            left.layoutParams = LinearLayout.LayoutParams(0, -1, prefs.getInt("columnWidth", 74).toFloat())
            info.layoutParams = LinearLayout.LayoutParams(0, -1, (100 - prefs.getInt("columnWidth", 74)).coerceAtLeast(10).toFloat())
            body.addView(left)
            body.addView(info)
        }
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")
        root.setOnLongClickListener { showSettings(); true }
        appList.setOnLongClickListener { showSettings(); true }
        if (searchVisible) showKeyboard()
    }

    private fun spacedParams(vertical: Boolean): LinearLayout.LayoutParams =
        if (vertical) LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12f) }
        else LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12f) }

    private fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        search.visibility = View.VISIBLE
        search.alpha = 0f
        search.translationX = -dp(22f).toFloat()
        search.animate().alpha(1f).translationX(0f).setDuration(260)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).withEndAction {
                if (searchVisible) showKeyboard()
            }.start()
        search.requestFocus()
    }

    private fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.animate().alpha(0f).translationX(-dp(22f).toFloat()).setDuration(210)
            .setInterpolator(android.view.animation.AccelerateInterpolator()).withEndAction {
                if (!searchVisible) {
                    search.setText("")
                    search.clearFocus()
                    search.visibility = View.GONE
                    search.alpha = 1f
                    search.translationX = 0f
                    renderApps("")
                }
            }.start()
    }

    private fun showKeyboard() {
        search.post {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val matches = apps.filter { it.label.contains(query.trim(), true) }
        matches.forEach { app ->
            val label = makeText(app.label, prefs.getFloat("appSize", 22f)).apply {
                val spacing = dp(prefs.getInt("spacing", 8).toFloat())
                setPadding(0, spacing, 0, spacing)
                setOnClickListener { packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } }
            }
            appList.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateInfo() {
        if (!::clockView.isInitialized) return
        val now = Date()
        val mode = prefs.getInt("rotation", 90)
        clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        val spanish = Locale("es", "ES")
        dateView.text = if (mode == 0) {
            SimpleDateFormat("EEEE, d 'de' MMMM", spanish).format(now).lowercase(spanish)
        } else {
            val day = SimpleDateFormat("dd", spanish).format(now)
            val month = SimpleDateFormat("MM", spanish).format(now)
            val weekday = SimpleDateFormat("EE", spanish).format(now).replace(".", "").take(2).uppercase(spanish)
            "$day/$month $weekday"
        }
        updateBatteryText()
    }

    private fun updateBatteryText() {
        if (!::batteryView.isInitialized) return
        val label = if (isCharging) "● $batteryPercent%" else "$batteryPercent%"
        val styled = SpannableString(label)
        if (isCharging) styled.setSpan(
            ForegroundColorSpan(Color.rgb(32, 190, 125)), 0, 1,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        batteryView.text = styled
    }

    private fun showSettings() {
        val options = arrayOf(
            "Color del texto", "Color del fondo", "Disposición del bloque informativo",
            "Tamaño del texto de aplicaciones", "Grosor de letra", "Separación entre aplicaciones",
            "Ancho de columna", "Márgenes", "Mostrar / ocultar reloj", "Mostrar / ocultar fecha",
            "Mostrar / ocultar batería", "Ocultar / mostrar barra superior del sistema", "Volver a cargar aplicaciones"
        )
        AlertDialog.Builder(this).setTitle("BSLauncher · Ajustes").setItems(options) { _, which ->
            when (which) {
                0 -> chooseColor("text", "Color del texto")
                1 -> chooseColor("bg", "Color del fondo")
                2 -> chooseRotation()
                3 -> chooseAppSize()
                4 -> chooseBold()
                5 -> chooseSpacing()
                6 -> chooseColumnWidth()
                7 -> chooseMargin()
                8 -> toggle("showClock", "Mostrar reloj")
                9 -> toggle("showDate", "Mostrar fecha")
                10 -> toggle("showBattery", "Mostrar batería")
                11 -> { prefs.edit().putBoolean("hideStatus", !prefs.getBoolean("hideStatus", true)).apply(); buildScreen() }
                12 -> { loadApps(); renderApps(search.text.toString()) }
            }
        }.setNegativeButton("Cerrar", null).show()
    }

    private fun chooseColor(key: String, title: String) {
        val labels = arrayOf("Negro", "Blanco", "Gris claro", "Gris", "Verde suave", "Azul suave")
        val values = intArrayOf(Color.BLACK, Color.WHITE, Color.LTGRAY, Color.GRAY, Color.rgb(130, 220, 170), Color.rgb(130, 180, 255))
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i ->
            prefs.edit().putInt(key, values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseRotation() {
        val labels = arrayOf("Lateral", "Lateral invertido 180°", "Superior")
        val values = intArrayOf(90, 270, 0)
        AlertDialog.Builder(this).setTitle("Reloj, fecha y batería").setItems(labels) { _, i ->
            prefs.edit().putInt("rotation", values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseAppSize() = chooseFloat("Tamaño del texto", "appSize", floatArrayOf(16f, 19f, 22f, 26f, 30f), arrayOf("Muy pequeño", "Pequeño", "Normal", "Grande", "Muy grande"))
    private fun chooseSpacing() = chooseInt("Separación entre aplicaciones", "spacing", intArrayOf(0, 4, 8, 12, 18), arrayOf("Ninguna", "Muy compacta", "Normal", "Amplia", "Muy amplia"))
    private fun chooseColumnWidth() = chooseInt("Ancho de la columna de aplicaciones", "columnWidth", intArrayOf(65, 70, 74, 78, 82), arrayOf("65%", "70%", "74%", "78%", "82%"))
    private fun chooseMargin() = chooseInt("Margen exterior", "margin", intArrayOf(8, 14, 20, 28, 36), arrayOf("8 dp", "14 dp", "20 dp", "28 dp", "36 dp"))

    private fun chooseBold() {
        val labels = arrayOf("Normal", "Negrita")
        AlertDialog.Builder(this).setTitle("Grosor de letra").setSingleChoiceItems(labels, if (prefs.getBoolean("bold", false)) 1 else 0) { d, i ->
            prefs.edit().putBoolean("bold", i == 1).apply(); d.dismiss(); buildScreen()
        }.setNegativeButton("Cancelar", null).show()
    }

    private fun toggle(key: String, title: String) {
        prefs.edit().putBoolean(key, !prefs.getBoolean(key, true)).apply()
        Toast.makeText(this, "$title ${if (prefs.getBoolean(key, true)) "activado" else "oculto"}", Toast.LENGTH_SHORT).show()
        buildScreen()
    }

    private fun chooseFloat(title: String, key: String, values: FloatArray, labels: Array<String>) {
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i -> prefs.edit().putFloat(key, values[i]).apply(); buildScreen() }.show()
    }

    private fun chooseInt(title: String, key: String, values: IntArray, labels: Array<String>) {
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i -> prefs.edit().putInt(key, values[i]).apply(); buildScreen() }.show()
    }
}
