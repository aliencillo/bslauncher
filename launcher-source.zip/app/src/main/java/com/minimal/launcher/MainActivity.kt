package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bslauncher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var batteryView: TextView
    private var apps: List<AppEntry> = emptyList()
    private var batteryPercent = 0
    private var isCharging = false
    private var searchVisible = false
    private var downX = 0f
    private var downY = 0f
    private var gestureHandled = false

    private val longPressHandler = Handler(Looper.getMainLooper())
    private var longPressTriggered = false
    private val longPressRunnable = Runnable {
        if (!longPressTriggered && !gestureHandled) {
            longPressTriggered = true
            showSettings()
        }
    }
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }
    private val REQUEST_BG_IMAGE = 1001

    private data class AppEntry(val label: String, val packageName: String)

    private val languages = linkedMapOf(
        "auto" to "Automático (sistema)",
        "es" to "Español", "es-ES" to "Español (España)", "es-MX" to "Español (México)",
        "es-AR" to "Español (Argentina)", "es-CO" to "Español (Colombia)",
        "es-CL" to "Español (Chile)", "es-PE" to "Español (Perú)",
        "ca" to "Català", "gl" to "Galego", "oc" to "Aranés (Occitan)", "eu" to "Euskara",
        "fr" to "Français", "de" to "Deutsch", "it" to "Italiano",
        "pt" to "Português", "pt-BR" to "Português (Brasil)",
        "zh" to "中文", "zh-CN" to "中文 (简体)", "zh-TW" to "中文 (繁體)",
        "ja" to "日本語", "ru" to "Русский"
    )

    private fun currentLocale(): Locale {
        val tag = prefs.getString("locale", "auto") ?: "auto"
        if (tag == "auto") return Locale.getDefault()
        return try { Locale.forLanguageTag(tag) } catch (_: Exception) { Locale.getDefault() }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPercent = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (::batteryView.isInitialized) updateBatteryText()
        }
    }

    // Panel: fondo gris oscuro, bordes redondeados, sin líneas, no ancho completo, Listo siempre
    private fun panelBg(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(28, 28, 28))
        cornerRadius = dp(18f).toFloat()
    }

    private fun showPanel(content: View, onListo: (() -> Unit)? = null) {
        val maxW = (resources.displayMetrics.widthPixels * 0.82f).toInt()
        val outerPad = dp(14f)
        content.background = panelBg()
        if (content.paddingTop < dp(12f)) {
            val p = dp(16f)
            content.setPadding(p, p, p, p)
        }
        val wrap = FrameLayout(this).apply {
            setPadding(outerPad, outerPad, outerPad, outerPad)
            setBackgroundColor(Color.TRANSPARENT)
            addView(content, FrameLayout.LayoutParams(maxW, -2))
        }
        val dialog = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setView(wrap)
            .setPositiveButton("Listo") { _, _ -> onListo?.invoke() }
            .create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.window?.setLayout(maxW + outerPad * 2, ViewGroup.LayoutParams.WRAP_CONTENT)
            dialog.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.WHITE)
            // Evitar animación de deslizamiento rara: posición centrada fija
            dialog.window?.setGravity(Gravity.CENTER)
        }
        dialog.show()
    }

    private fun showListPanel(items: Array<String>, onPick: (Int) -> Unit) {
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = dp(10f)
            setPadding(p, p, p, p)
            background = panelBg()
        }
        items.forEachIndexed { i, label ->
            val tv = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 16f
                typeface = currentTypeface()
                setPadding(dp(18f), dp(15f), dp(18f), dp(15f))
            }
            list.addView(tv, LinearLayout.LayoutParams(-1, -2))
        }
        val maxW = (resources.displayMetrics.widthPixels * 0.82f).toInt()
        val outerPad = dp(14f)
        val wrap = FrameLayout(this).apply {
            setPadding(outerPad, outerPad, outerPad, outerPad)
            setBackgroundColor(Color.TRANSPARENT)
            addView(list, FrameLayout.LayoutParams(maxW, -2))
        }
        var dialog: AlertDialog? = null
        // Rebind clicks with dismiss
        for (i in 0 until list.childCount) {
            val child = list.getChildAt(i) as TextView
            val idx = i
            child.setOnClickListener {
                dialog?.dismiss()
                onPick(idx)
            }
        }
        dialog = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setView(wrap)
            .setPositiveButton("Listo") { d, _ -> d.dismiss() }
            .create()
        dialog?.setOnShowListener {
            dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog?.window?.setLayout(maxW + outerPad * 2, ViewGroup.LayoutParams.WRAP_CONTENT)
            dialog?.window?.setGravity(Gravity.CENTER)
            dialog?.getButton(AlertDialog.BUTTON_POSITIVE)?.setTextColor(Color.WHITE)
        }
        dialog?.show()
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                gestureHandled = false; longPressTriggered = false
                longPressHandler.removeCallbacks(longPressRunnable)
                longPressHandler.postDelayed(longPressRunnable, 550)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                    longPressHandler.removeCallbacks(longPressRunnable)
                }
                if (!gestureHandled && abs(dx) > dp(42f) && abs(dx) > abs(dy) * 1.35f) {
                    gestureHandled = true
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (dx < 0 && !searchVisible) openSearch()
                    else if (dx > 0 && searchVisible) closeSearch()
                }
                if (gestureHandled) return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                longPressHandler.removeCallbacks(longPressRunnable)
                if (gestureHandled) { gestureHandled = false; return true }
                if (longPressTriggered) return true
            }
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars()
        loadApps()
        buildScreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        updateInfo()
        window.decorView.post(object : Runnable {
            override fun run() {
                if (isFinishing) return
                updateInfo()
                window.decorView.postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        longPressHandler.removeCallbacks(longPressRunnable)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_BG_IMAGE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    openFileOutput("bg_image.jpg", MODE_PRIVATE).use { output -> input.copyTo(output) }
                }
                prefs.edit().putString("bgMode", "image").putString("bgImageUri", uri.toString()).apply()
                softApplyBackground()
            } catch (_: Exception) {
                Toast.makeText(this, "No se pudo cargar la imagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun loadBackground(): Drawable {
        if ((prefs.getString("bgMode", "color") ?: "color") == "image") {
            try {
                val file = getFileStreamPath("bg_image.jpg")
                if (file != null && file.exists()) {
                    val bmp = BitmapFactory.decodeFile(file.absolutePath)
                    if (bmp != null) return BitmapDrawable(resources, bmp)
                }
            } catch (_: Exception) {}
        }
        return ColorDrawable(prefColor("bg", Color.BLACK))
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun prefColor(key: String, fallback: Int) = prefs.getInt(key, fallback)

    private fun getFavorites(): MutableSet<String> =
        prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun saveFavorites(set: Set<String>) {
        prefs.edit().putStringSet("favorites", set).apply()
    }
    private fun isFavoritesOnly(): Boolean = prefs.getBoolean("favoritesOnly", false)
    private fun setFavoritesOnly(value: Boolean) {
        prefs.edit().putBoolean("favoritesOnly", value).apply()
    }

    private fun currentTypeface(): Typeface {
        val family = prefs.getString("fontFamily", "sans-serif") ?: "sans-serif"
        val style = if (prefs.getBoolean("bold", false)) Typeface.BOLD else Typeface.NORMAL
        return Typeface.create(family, style)
    }

    private fun applyTypefaceRecursive(v: View, tf: Typeface) {
        when (v) {
            is TextView -> v.typeface = tf
            is ViewGroup -> {
                for (i in 0 until v.childCount) applyTypefaceRecursive(v.getChildAt(i), tf)
            }
        }
    }

    private fun softApplyTypeface() {
        if (!::root.isInitialized) { buildScreen(); return }
        applyTypefaceRecursive(root, currentTypeface())
        renderApps(if (::search.isInitialized) search.text.toString() else "")
    }

    private fun softApplyTextColor() {
        if (!::root.isInitialized) { buildScreen(); return }
        val c = prefColor("text", Color.WHITE)
        if (::clockView.isInitialized) clockView.setTextColor(c)
        if (::dateView.isInitialized) dateView.setTextColor(c)
        if (::batteryView.isInitialized) {
            updateBatteryText()
            if (!isCharging) batteryView.setTextColor(c)
        }
        if (::search.isInitialized) search.setTextColor(c)
        renderApps(if (::search.isInitialized) search.text.toString() else "")
    }

    private fun softApplyBackground() {
        if (!::root.isInitialized) { buildScreen(); return }
        root.background = loadBackground()
        val bg = prefColor("bg", Color.BLACK)
        window.statusBarColor = bg
        window.navigationBarColor = bg
    }

    private fun applySystemBars() {
        val hide = prefs.getBoolean("hideStatus", true)
        if (hide) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        window.statusBarColor = prefColor("bg", Color.BLACK)
        window.navigationBarColor = prefColor("bg", Color.BLACK)
    }

    private fun loadApps() {
        val pm = packageManager
        apps = pm.getInstalledApplications(0).mapNotNull { info ->
            if (info.packageName == packageName) return@mapNotNull null
            pm.getLaunchIntentForPackage(info.packageName) ?: return@mapNotNull null
            AppEntry(pm.getApplicationLabel(info).toString(), info.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    private fun makeText(value: String, size: Float, color: Int = prefColor("text", Color.WHITE)): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = currentTypeface()
            includeFontPadding = false
            setSingleLine(true)
        }

    private fun openClock() {
        val candidates = listOf(
            Intent(AlarmClock.ACTION_SHOW_ALARMS),
            Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CLOCK"),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.deskclock")
        )
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i.resolveActivity(packageManager) != null) { startActivity(i); return }
            } catch (_: Exception) {}
        }
        Toast.makeText(this, "No se encontró app de reloj", Toast.LENGTH_SHORT).show()
    }

    private fun openCalendar() {
        val time = System.currentTimeMillis()
        val candidates = listOf(
            Intent(Intent.ACTION_VIEW).setData(Uri.parse("content://com.android.calendar/time/$time")),
            Intent(Intent.ACTION_VIEW).setData(
                CalendarContract.CONTENT_URI.buildUpon().appendPath("time").appendPath(time.toString()).build()
            ),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.calendar")
        )
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i.resolveActivity(packageManager) != null) { startActivity(i); return }
            } catch (_: Exception) {}
        }
        Toast.makeText(this, "No se encontró app de calendario", Toast.LENGTH_SHORT).show()
    }

    private fun buildScreen() {
        applySystemBars()
        val padH = dp(24f)
        val padTop = dp(36f)
        val padBottom = dp(36f)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = loadBackground()
            setPadding(padH, padTop, padH, padBottom)
            clipChildren = false
            clipToPadding = false
        }

        val layoutMode = prefs.getInt("rotation", 90)

        val body = LinearLayout(this).apply {
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            clipChildren = false
        }

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = true
            isFillViewport = true
            isLongClickable = false
            setPadding(0, dp(4f), 0, dp(4f))
        }
        appList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            isLongClickable = false
        }
        scroll.addView(appList, FrameLayout.LayoutParams(-1, -2))

        search = EditText(this).apply {
            hint = "Buscar..."
            setHintTextColor(Color.GRAY)
            setTextColor(prefColor("text", Color.WHITE))
            textSize = 17f
            typeface = currentTypeface()
            setSingleLine(true)
            isFocusableInTouchMode = true
            background = null
            setPadding(0, dp(6f), 0, dp(6f))
            visibility = if (searchVisible) View.VISIBLE else View.GONE
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }

        val clockSize = prefs.getFloat("clockSize", 36f)
        val metaSize = prefs.getFloat("dateSize", 13f)

        clockView = makeText("00:00", clockSize).apply { setOnClickListener { openClock() } }
        dateView = makeText("", metaSize).apply { setOnClickListener { openCalendar() } }
        batteryView = makeText("100%", metaSize)

        if (layoutMode == 0) {
            clockView.gravity = Gravity.START
            dateView.gravity = Gravity.START
            dateView.setSingleLine(false)
            dateView.maxLines = 2
            batteryView.gravity = Gravity.START

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.START
            }
            info.addView(clockView, LinearLayout.LayoutParams(-2, -2))
            info.addView(dateView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6f) })
            info.addView(batteryView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6f) })

            body.addView(info, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) })
            body.addView(search, LinearLayout.LayoutParams(-1, dp(44f)).apply { bottomMargin = dp(4f) })
            body.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            // LATERAL: una fila hora|fecha|batería rotada 90° → de arriba abajo
            // Más espacio en la columna derecha para que no se recorte la fecha
            clockView.gravity = Gravity.CENTER
            dateView.gravity = Gravity.CENTER
            dateView.setSingleLine(true)
            batteryView.gravity = Gravity.CENTER

            val gap = dp(18f)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                clipChildren = false
                // No limitar ancho: la fecha completa debe caber
            }
            row.addView(clockView, LinearLayout.LayoutParams(-2, -2))
            row.addView(dateView, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = gap })
            row.addView(batteryView, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = gap })

            val info = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
            }
            info.addView(row, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))

            val rot = if (layoutMode == 90) 90f else -90f
            row.rotation = rot

            row.post {
                val w = row.width.toFloat()
                val h = row.height.toFloat()
                row.pivotX = w / 2f
                row.pivotY = h / 2f
                // Reservar espacio vertical visual (= ancho de la fila sin rotar)
                val needed = max(w, h).toInt() + dp(16f)
                info.minimumHeight = needed
                info.requestLayout()
            }

            var infoTouchStartY = 0f
            var infoTouchLastY = 0f
            var infoScrollActive = false
            info.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        infoTouchStartY = event.y; infoTouchLastY = event.y
                        infoScrollActive = false; false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!infoScrollActive && abs(event.y - infoTouchStartY) > touchSlop) {
                            infoScrollActive = true
                            longPressHandler.removeCallbacks(longPressRunnable)
                        }
                        if (infoScrollActive) {
                            scroll.scrollBy(0, (infoTouchLastY - event.y).toInt())
                            infoTouchLastY = event.y
                        }
                        infoScrollActive
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val c = infoScrollActive; infoScrollActive = false; c
                    }
                    else -> infoScrollActive
                }
            }

            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(search, LinearLayout.LayoutParams(-1, dp(44f)))
            left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

            // Más espacio horizontal a la columna del reloj (evita corte de letras)
            left.layoutParams = LinearLayout.LayoutParams(0, -1, 58f)
            info.layoutParams = LinearLayout.LayoutParams(0, -1, 42f)

            body.clipChildren = false
            root.clipChildren = false
            body.addView(left)
            body.addView(info)
        }

        root.addView(body)
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")
        if (searchVisible) showKeyboard()
    }

    private fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        search.visibility = View.VISIBLE
        search.alpha = 0f
        search.translationY = -dp(12f).toFloat()
        search.animate().alpha(1f).translationY(0f).setDuration(320)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
            .withEndAction { if (searchVisible) showKeyboard() }.start()
        search.requestFocus()
    }

    private fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        search.animate().alpha(0f).translationY(-dp(12f).toFloat()).setDuration(260)
            .setInterpolator(android.view.animation.AccelerateInterpolator(1.2f))
            .withEndAction {
                if (!searchVisible) {
                    search.setText(""); search.clearFocus()
                    search.visibility = View.GONE
                    search.alpha = 1f; search.translationY = 0f
                    renderApps("")
                }
            }.start()
    }

    private fun showKeyboard() {
        search.post {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val favs = getFavorites()
        val q = query.trim()
        val matches = apps.filter { app ->
            val nameOk = q.isEmpty() || app.label.contains(q, true)
            val favOk = q.isNotEmpty() || !isFavoritesOnly() || favs.contains(app.packageName)
            nameOk && favOk
        }
        val appSize = prefs.getFloat("appSize", 22f)
        val spacing = dp(10f)
        matches.forEach { app ->
            val label = makeText(app.label, appSize).apply {
                setPadding(0, spacing, 0, spacing)
                setSingleLine(false); maxLines = 2
                setOnClickListener {
                    packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
                }
                isLongClickable = false
            }
            appList.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateInfo() {
        if (!::clockView.isInitialized) return
        val now = Date()
        val loc = currentLocale()
        val mode = prefs.getInt("rotation", 90)
        clockView.text = SimpleDateFormat("HH:mm", loc).format(now)
        dateView.text = if (mode == 0) {
            SimpleDateFormat("EEEE, d MMMM", loc).format(now)
                .replaceFirstChar { if (it.isLowerCase()) it.titlecase(loc) else it.toString() }
        } else {
            val weekday = SimpleDateFormat("EEE", loc).format(now).replace(".", "").uppercase(loc).take(3)
            val day = SimpleDateFormat("d", loc).format(now)
            val month = SimpleDateFormat("MMM", loc).format(now).replace(".", "").uppercase(loc).take(3)
            "$weekday, $day $month"
        }
        updateBatteryText()
    }

    private fun updateBatteryText() {
        if (!::batteryView.isInitialized) return
        val label = if (isCharging) "● $batteryPercent%" else "$batteryPercent%"
        val styled = SpannableString(label)
        if (isCharging) {
            styled.setSpan(
                ForegroundColorSpan(Color.rgb(32, 190, 125)), 0, 1,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        batteryView.text = styled
        batteryView.visibility = View.VISIBLE
    }

    private fun showSettings() {
        val hide = prefs.getBoolean("hideStatus", true)
        val barLabel = if (hide) "Mostrar barra del sistema" else "Ocultar barra del sistema"
        val options = arrayOf(
            "Color del texto",
            "Fondo",
            "Fecha / Hora / Batería",
            "Idioma",
            "Tamaño del texto",
            "Tipo de letra",
            "Grosor de letra",
            barLabel,
            "Aplicaciones",
            "Volver a cargar aplicaciones"
        )
        showListPanel(options) { which ->
            when (which) {
                0 -> chooseColor("text")
                1 -> chooseBackground()
                2 -> chooseRotation()
                3 -> chooseLanguage()
                4 -> chooseAppSize()
                5 -> chooseFont()
                6 -> chooseBold()
                7 -> {
                    prefs.edit().putBoolean("hideStatus", !prefs.getBoolean("hideStatus", true)).apply()
                    buildScreen()
                }
                8 -> showAppsSettings()
                9 -> { loadApps(); renderApps(search.text.toString()) }
            }
        }
    }

    private fun chooseBackground() {
        // Mismo diseño que apps: arriba Color plano + lista de colores, y "Cambiar" pide imagen
        val bgColor = Color.rgb(28, 28, 28)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
            val p = dp(16f)
            setPadding(p, p, p, p)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Color plano"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = currentTypeface()
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val changeBtn = TextView(this).apply {
            text = "Cambiar"
            setTextColor(Color.LTGRAY)
            textSize = 15f
            setPadding(dp(12f), dp(8f), dp(4f), dp(8f))
            setOnClickListener {
                // Pedir imagen
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }
                try {
                    startActivityForResult(intent, REQUEST_BG_IMAGE)
                } catch (_: Exception) {
                    startActivityForResult(Intent(Intent.ACTION_PICK).apply { type = "image/*" }, REQUEST_BG_IMAGE)
                }
            }
        }
        header.addView(title)
        header.addView(changeBtn)
        outer.addView(header)

        val labels = arrayOf(
            "Negro", "Blanco", "Gris claro", "Gris",
            "Rojo", "Naranja", "Rosa", "Amarillo",
            "Verde suave", "Azul suave"
        )
        val values = intArrayOf(
            Color.BLACK, Color.WHITE, Color.LTGRAY, Color.GRAY,
            Color.rgb(220, 60, 60), Color.rgb(240, 140, 40),
            Color.rgb(240, 120, 170), Color.rgb(240, 210, 50),
            Color.rgb(130, 220, 170), Color.rgb(130, 180, 255)
        )
        labels.forEachIndexed { i, label ->
            val tv = TextView(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 16f
                typeface = currentTypeface()
                setPadding(0, dp(14f), 0, dp(14f))
                setOnClickListener {
                    prefs.edit().putInt("bg", values[i]).putString("bgMode", "color").apply()
                    softApplyBackground()
                }
            }
            outer.addView(tv)
        }

        showPanel(outer)
    }

    private fun showAppsSettings() {
        val bgColor = Color.rgb(28, 28, 28)
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
            val p = dp(16f)
            setPadding(p, p, p, p)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val modeLabel = TextView(this).apply {
            text = if (isFavoritesOnly()) "Mostrar favoritos" else "Mostrar todos"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = currentTypeface()
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val changeBtn = TextView(this).apply {
            text = "Cambiar"
            setTextColor(Color.LTGRAY)
            textSize = 15f
            setPadding(dp(12f), dp(8f), dp(4f), dp(8f))
            setOnClickListener {
                val next = !isFavoritesOnly()
                setFavoritesOnly(next)
                modeLabel.text = if (next) "Mostrar favoritos" else "Mostrar todos"
                renderApps(search.text.toString())
            }
        }
        header.addView(modeLabel)
        header.addView(changeBtn)
        outer.addView(header)

        val favs = getFavorites()
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(340f))
            setBackgroundColor(bgColor)
            isVerticalScrollBarEnabled = false
        }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bgColor)
        }
        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setBackgroundColor(bgColor)
                setPadding(0, dp(8f), 0, dp(8f))
            }
            val cb = CheckBox(this).apply {
                isChecked = favs.contains(app.packageName)
                buttonTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
                setOnCheckedChangeListener { _, checked ->
                    val current = getFavorites()
                    if (checked) current.add(app.packageName) else current.remove(app.packageName)
                    saveFavorites(current)
                    if (isFavoritesOnly()) renderApps(search.text.toString())
                }
            }
            val name = TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = currentTypeface()
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { cb.isChecked = !cb.isChecked }
            }
            row.addView(cb); row.addView(name)
            list.addView(row)
        }
        scroll.addView(list)
        outer.addView(scroll)

        showPanel(outer) { renderApps(search.text.toString()) }
    }

    private fun chooseColor(key: String) {
        val labels = arrayOf(
            "Negro", "Blanco", "Gris claro", "Gris",
            "Rojo", "Naranja", "Rosa", "Amarillo",
            "Verde suave", "Azul suave"
        )
        val values = intArrayOf(
            Color.BLACK, Color.WHITE, Color.LTGRAY, Color.GRAY,
            Color.rgb(220, 60, 60), Color.rgb(240, 140, 40),
            Color.rgb(240, 120, 170), Color.rgb(240, 210, 50),
            Color.rgb(130, 220, 170), Color.rgb(130, 180, 255)
        )
        showListPanel(labels) { i ->
            val ed = prefs.edit().putInt(key, values[i])
            if (key == "bg") ed.putString("bgMode", "color")
            ed.apply()
            if (key == "bg") softApplyBackground() else softApplyTextColor()
        }
    }

    private fun chooseRotation() {
        showListPanel(arrayOf("Lateral", "Lateral invertido", "Superior")) { i ->
            prefs.edit().putInt("rotation", intArrayOf(90, 270, 0)[i]).apply()
            buildScreen()
        }
    }

    private fun chooseLanguage() {
        val keys = languages.keys.toList()
        val labels = languages.values.toTypedArray()
        showListPanel(labels) { i ->
            prefs.edit().putString("locale", keys[i]).apply()
            buildScreen()
        }
    }

    private fun chooseAppSize() {
        val values = floatArrayOf(14f, 18f, 22f, 28f, 36f, 44f)
        val labels = arrayOf("Muy pequeño", "Pequeño", "Normal", "Grande", "Muy grande", "Enorme")
        showListPanel(labels) { i ->
            prefs.edit().putFloat("appSize", values[i]).apply()
            renderApps(if (::search.isInitialized) search.text.toString() else "")
        }
    }

    private fun chooseFont() {
        val labels = arrayOf(
            "Sans (predeterminada)", "Sans Light", "Sans Medium",
            "Sans Condensed", "Serif", "Monoespaciada"
        )
        val values = arrayOf(
            "sans-serif", "sans-serif-light", "sans-serif-medium",
            "sans-serif-condensed", "serif", "monospace"
        )
        showListPanel(labels) { i ->
            prefs.edit().putString("fontFamily", values[i]).apply()
            softApplyTypeface()
        }
    }

    private fun chooseBold() {
        showListPanel(arrayOf("Normal", "Negrita")) { i ->
            prefs.edit().putBoolean("bold", i == 1).apply()
            softApplyTypeface()
        }
    }
}
