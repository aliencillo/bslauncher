package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bslauncher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var batteryView: TextView
    private var apps: List<AppEntry> = emptyList()
    private var batteryPercent = 0
    private var isCharging = false
    private var searchVisible = false
    private var downX = 0f
    private var downY = 0f
    private var gestureHandled = false

    private val longPressHandler = Handler(Looper.getMainLooper())
    private var longPressTriggered = false
    private val longPressRunnable = Runnable {
        if (!longPressTriggered && !gestureHandled) {
            longPressTriggered = true
            showSettings()
        }
    }
    private val touchSlop by lazy { ViewConfiguration.get(this).scaledTouchSlop }

    private data class AppEntry(val label: String, val packageName: String)

    private val languages = linkedMapOf(
        "auto" to "Automático (sistema)",
        "es" to "Español",
        "es-ES" to "Español (España)",
        "es-MX" to "Español (México)",
        "es-AR" to "Español (Argentina)",
        "es-CO" to "Español (Colombia)",
        "es-CL" to "Español (Chile)",
        "es-PE" to "Español (Perú)",
        "ca" to "Català",
        "gl" to "Galego",
        "oc" to "Aranés (Occitan)",
        "eu" to "Euskara",
        "fr" to "Français",
        "de" to "Deutsch",
        "it" to "Italiano",
        "pt" to "Português",
        "pt-BR" to "Português (Brasil)",
        "zh" to "中文",
        "zh-CN" to "中文 (简体)",
        "zh-TW" to "中文 (繁體)",
        "ja" to "日本語",
        "ru" to "Русский"
    )

    private fun currentLocale(): Locale {
        val tag = prefs.getString("locale", "auto") ?: "auto"
        if (tag == "auto") return Locale.getDefault()
        return try { Locale.forLanguageTag(tag) } catch (_: Exception) { Locale.getDefault() }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPercent = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (::batteryView.isInitialized) updateBatteryText()
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                gestureHandled = false; longPressTriggered = false
                longPressHandler.removeCallbacks(longPressRunnable)
                longPressHandler.postDelayed(longPressRunnable, 550)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                    longPressHandler.removeCallbacks(longPressRunnable)
                }
                if (!gestureHandled && abs(dx) > dp(42f) && abs(dx) > abs(dy) * 1.35f) {
                    gestureHandled = true
                    longPressHandler.removeCallbacks(longPressRunnable)
                    if (dx < 0 && !searchVisible) openSearch()
                    else if (dx > 0 && searchVisible) closeSearch()
                }
                if (gestureHandled) return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                longPressHandler.removeCallbacks(longPressRunnable)
                if (gestureHandled) { gestureHandled = false; return true }
                if (longPressTriggered) return true
            }
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars()
        loadApps()
        buildScreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        updateInfo()
        window.decorView.post(object : Runnable {
            override fun run() {
                if (isFinishing) return
                updateInfo()
                window.decorView.postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        longPressHandler.removeCallbacks(longPressRunnable)
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun prefColor(key: String, fallback: Int) = prefs.getInt(key, fallback)

    private fun getFavorites(): MutableSet<String> =
        prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()
    private fun saveFavorites(set: Set<String>) {
        prefs.edit().putStringSet("favorites", set).apply()
    }
    private fun isFavoritesOnly(): Boolean = prefs.getBoolean("favoritesOnly", false)
    private fun setFavoritesOnly(value: Boolean) {
        prefs.edit().putBoolean("favoritesOnly", value).apply()
    }

    private fun currentTypeface(): Typeface {
        val family = prefs.getString("fontFamily", "sans-serif") ?: "sans-serif"
        val style = if (prefs.getBoolean("bold", false)) Typeface.BOLD else Typeface.NORMAL
        return Typeface.create(family, style)
    }

    private fun applySystemBars() {
        val hide = prefs.getBoolean("hideStatus", true)
        if (hide) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        window.statusBarColor = prefColor("bg", Color.BLACK)
        window.navigationBarColor = prefColor("bg", Color.BLACK)
    }

    private fun loadApps() {
        val pm = packageManager
        apps = pm.getInstalledApplications(0).mapNotNull { info ->
            if (info.packageName == packageName) return@mapNotNull null
            pm.getLaunchIntentForPackage(info.packageName) ?: return@mapNotNull null
            AppEntry(pm.getApplicationLabel(info).toString(), info.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    private fun makeText(value: String, size: Float, color: Int = prefColor("text", Color.WHITE)): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = currentTypeface()
            includeFontPadding = false
        }

    private fun openClock() {
        val candidates = listOf(
            Intent(AlarmClock.ACTION_SHOW_ALARMS),
            Intent(AlarmClock.ACTION_SET_ALARM).apply { putExtra(AlarmClock.EXTRA_SKIP_UI, false) },
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.deskclock"),
            Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CLOCK")
        )
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i.resolveActivity(packageManager) != null) { startActivity(i); return }
            } catch (_: Exception) {}
        }
        Toast.makeText(this, "No se encontró app de reloj", Toast.LENGTH_SHORT).show()
    }

    private fun openCalendar() {
        val time = System.currentTimeMillis()
        val candidates = listOf(
            Intent(Intent.ACTION_VIEW).setData(Uri.parse("content://com.android.calendar/time/$time")),
            Intent(Intent.ACTION_VIEW).setData(CalendarContract.CONTENT_URI.buildUpon()
                .appendPath("time").appendPath(time.toString()).build()),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR),
            Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.APP_CALENDAR"),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.google.android.calendar"),
            Intent(Intent.ACTION_EDIT).setType("vnd.android.cursor.item/event")
        )
        for (i in candidates) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                if (i.resolveActivity(packageManager) != null) { startActivity(i); return }
            } catch (_: Exception) {}
        }
        Toast.makeText(this, "No se encontró app de calendario", Toast.LENGTH_SHORT).show()
    }

    private fun buildScreen() {
        applySystemBars()
        val bg = prefColor("bg", Color.BLACK)

        // Márgenes FIJOS amplios: la lista de apps NUNCA llega a los bordes
        val padH = dp(24f)
        val padTop = dp(36f)
        val padBottom = dp(36f)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(padH, padTop, padH, padBottom)
            clipChildren = true
            clipToPadding = true
        }

        val layoutMode = prefs.getInt("rotation", 90) // 90 lateral, 270 invertido, 0 superior

        val body = LinearLayout(this).apply {
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
            clipChildren = true
        }

        // Lista de apps (ScrollView)
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = true
            isFillViewport = true
            isLongClickable = false
            setPadding(0, dp(4f), 0, dp(4f))
        }
        appList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            isLongClickable = false
        }
        scroll.addView(appList, android.widget.FrameLayout.LayoutParams(-1, -2))

        search = EditText(this).apply {
            hint = "Buscar..."
            setHintTextColor(Color.GRAY)
            setTextColor(prefColor("text", Color.WHITE))
            textSize = 17f
            typeface = currentTypeface()
            setSingleLine(true)
            isFocusableInTouchMode = true
            background = null
            setPadding(0, dp(6f), 0, dp(6f))
            visibility = if (searchVisible) View.VISIBLE else View.GONE
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }

        // Bloque informativo
        val clockSize = prefs.getFloat("clockSize", 34f)
        val metaSize = prefs.getFloat("dateSize", 13f)

        clockView = makeText("00:00", clockSize).apply {
            setOnClickListener { openClock() }
        }
        dateView = makeText("", metaSize).apply {
            setOnClickListener { openCalendar() }
        }
        batteryView = makeText("100%", metaSize)

        if (layoutMode == 0) {
            // ═══════════════ SUPERIOR ═══════════════
            // Info arriba, alineada a la izquierda. Lista SOLO debajo.
            clockView.gravity = Gravity.START
            dateView.gravity = Gravity.START
            batteryView.gravity = Gravity.START

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.START
            }
            info.addView(clockView, LinearLayout.LayoutParams(-2, -2))
            info.addView(dateView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6f) })
            info.addView(batteryView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6f) })

            body.addView(info, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12f) })
            // Búsqueda: cuando visible ocupa su fila y empuja la lista
            body.addView(search, LinearLayout.LayoutParams(-1, dp(44f)).apply { bottomMargin = dp(4f) })
            body.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            // ═══════════════ LATERAL ═══════════════
            // Columna derecha: reloj, fecha completa y batería apilados en VERTICAL
            // (sin rotación de layout: se ve TODO completo y en orden)
            // Texto centrado en la columna derecha.
            clockView.gravity = Gravity.CENTER_HORIZONTAL
            dateView.gravity = Gravity.CENTER_HORIZONTAL
            dateView.setSingleLine(false)
            dateView.maxLines = 3
            batteryView.gravity = Gravity.CENTER_HORIZONTAL

            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                // Rotar el bloque entero para aspecto vertical tipo la captura
                // Usamos un contenedor con tamaño medido tras layout
            }

            // Columna vertical: reloj → fecha completa → batería (todo visible, sin recortes)
            info.addView(clockView, LinearLayout.LayoutParams(-2, -2))
            info.addView(dateView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10f) })
            info.addView(batteryView, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8f) })
            info.gravity = Gravity.CENTER

            // Scroll desde la columna del reloj
            var infoTouchStartY = 0f
            var infoTouchLastY = 0f
            var infoScrollActive = false
            info.setOnTouchListener { _, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        infoTouchStartY = event.y; infoTouchLastY = event.y
                        infoScrollActive = false; false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (!infoScrollActive && abs(event.y - infoTouchStartY) > touchSlop) {
                            infoScrollActive = true
                            longPressHandler.removeCallbacks(longPressRunnable)
                        }
                        if (infoScrollActive) {
                            scroll.scrollBy(0, (infoTouchLastY - event.y).toInt())
                            infoTouchLastY = event.y
                        }
                        infoScrollActive
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val c = infoScrollActive; infoScrollActive = false; c
                    }
                    else -> infoScrollActive
                }
            }

            val left = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }
            left.addView(search, LinearLayout.LayoutParams(-1, dp(44f)))
            left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

            // Más espacio a la columna del reloj para que quepan fecha larga + batería
            left.layoutParams = LinearLayout.LayoutParams(0, -1, 62f)
            info.layoutParams = LinearLayout.LayoutParams(0, -1, 38f)

            body.addView(left)
            body.addView(info)

        }

        root.addView(body)
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")
        if (searchVisible) showKeyboard()
    }

    private fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        search.visibility = View.VISIBLE
        search.alpha = 0f
        search.translationY = -dp(12f).toFloat()
        search.animate()
            .alpha(1f).translationY(0f)
            .setDuration(320)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
            .withEndAction { if (searchVisible) showKeyboard() }
            .start()
        search.requestFocus()
    }

    private fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        search.animate()
            .alpha(0f).translationY(-dp(12f).toFloat())
            .setDuration(260)
            .setInterpolator(android.view.animation.AccelerateInterpolator(1.2f))
            .withEndAction {
                if (!searchVisible) {
                    search.setText("")
                    search.clearFocus()
                    search.visibility = View.GONE
                    search.alpha = 1f
                    search.translationY = 0f
                    renderApps("")
                }
            }.start()
    }

    private fun showKeyboard() {
        search.post {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val favs = getFavorites()
        val q = query.trim()
        val matches = apps.filter { app ->
            val nameOk = q.isEmpty() || app.label.contains(q, true)
            val favOk = q.isNotEmpty() || !isFavoritesOnly() || favs.contains(app.packageName)
            nameOk && favOk
        }
        val appSize = prefs.getFloat("appSize", 22f)
        val spacing = dp(10f)
        matches.forEach { app ->
            val label = makeText(app.label, appSize).apply {
                setPadding(0, spacing, 0, spacing)
                setSingleLine(false)
                maxLines = 2
                setOnClickListener {
                    packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
                }
                isLongClickable = false
            }
            appList.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateInfo() {
        if (!::clockView.isInitialized) return
        val now = Date()
        val loc = currentLocale()
        clockView.text = SimpleDateFormat("HH:mm", loc).format(now)
        dateView.text = SimpleDateFormat("EEEE, d MMMM", loc).format(now)
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase(loc) else it.toString() }
        updateBatteryText()
    }

    private fun updateBatteryText() {
        if (!::batteryView.isInitialized) return
        val label = if (isCharging) "● $batteryPercent%" else "$batteryPercent%"
        val styled = SpannableString(label)
        if (isCharging) {
            styled.setSpan(
                ForegroundColorSpan(Color.rgb(32, 190, 125)),
                0, 1,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        batteryView.text = styled
        batteryView.visibility = View.VISIBLE
    }

    private fun showSettings() {
        val options = arrayOf(
            "Color del texto",
            "Color del fondo",
            "Fecha / Hora / Batería",
            "Idioma",
            "Tamaño del texto",
            "Tipo de letra",
            "Grosor de letra",
            "Ocultar / mostrar barra del sistema",
            "Aplicaciones",
            "Volver a cargar aplicaciones"
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseColor("text")
                    1 -> chooseColor("bg")
                    2 -> chooseRotation()
                    3 -> chooseLanguage()
                    4 -> chooseAppSize()
                    5 -> chooseFont()
                    6 -> chooseBold()
                    7 -> {
                        prefs.edit().putBoolean("hideStatus", !prefs.getBoolean("hideStatus", true)).apply()
                        buildScreen()
                    }
                    8 -> showAppsSettings()
                    9 -> { loadApps(); renderApps(search.text.toString()) }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun chooseLanguage() {
        val keys = languages.keys.toList()
        val labels = languages.values.toTypedArray()
        val current = prefs.getString("locale", "auto") ?: "auto"
        val checked = keys.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setSingleChoiceItems(labels, checked) { d, i ->
                prefs.edit().putString("locale", keys[i]).apply()
                d.dismiss()
                buildScreen()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showAppsSettings() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(16f), dp(20f), dp(8f))
            setBackgroundColor(Color.BLACK)
        }
        val modeLabel = TextView(this).apply {
            text = if (isFavoritesOnly()) "Mostrar favoritos  ·  tocar para cambiar"
                   else "Mostrar todos  ·  tocar para cambiar"
            setTextColor(Color.WHITE)
            textSize = 15f
            typeface = currentTypeface()
            setPadding(0, 0, 0, dp(12f))
            setOnClickListener {
                val next = !isFavoritesOnly()
                setFavoritesOnly(next)
                text = if (next) "Mostrar favoritos  ·  tocar para cambiar"
                       else "Mostrar todos  ·  tocar para cambiar"
                renderApps(search.text.toString())
            }
        }
        outer.addView(modeLabel)
        outer.addView(View(this).apply {
            setBackgroundColor(Color.DKGRAY)
            layoutParams = LinearLayout.LayoutParams(-1, 1).apply { bottomMargin = dp(10f) }
        })

        val favs = getFavorites()
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(340f))
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6f), 0, dp(6f))
            }
            val cb = CheckBox(this).apply {
                isChecked = favs.contains(app.packageName)
                setOnCheckedChangeListener { _, checked ->
                    val current = getFavorites()
                    if (checked) current.add(app.packageName) else current.remove(app.packageName)
                    saveFavorites(current)
                    if (isFavoritesOnly()) renderApps(search.text.toString())
                }
            }
            val name = TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = currentTypeface()
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { cb.isChecked = !cb.isChecked }
            }
            row.addView(cb); row.addView(name)
            list.addView(row)
        }
        scroll.addView(list)
        outer.addView(scroll)

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setView(outer)
            .setPositiveButton("Listo") { _, _ -> renderApps(search.text.toString()) }
            .show()
    }

    private fun chooseColor(key: String) {
        val labels = arrayOf(
            "Negro", "Blanco", "Gris claro", "Gris",
            "Rojo", "Naranja", "Rosa", "Amarillo",
            "Verde suave", "Azul suave"
        )
        val values = intArrayOf(
            Color.BLACK, Color.WHITE, Color.LTGRAY, Color.GRAY,
            Color.rgb(220, 60, 60),   // rojo
            Color.rgb(240, 140, 40),  // naranja
            Color.rgb(240, 120, 170), // rosa
            Color.rgb(240, 210, 50),  // amarillo
            Color.rgb(130, 220, 170), // verde suave
            Color.rgb(130, 180, 255)  // azul suave
        )
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setItems(labels) { _, i ->
                prefs.edit().putInt(key, values[i]).apply(); buildScreen()
            }.show()
    }

    private fun chooseRotation() {
        val labels = arrayOf("Lateral", "Lateral invertido", "Superior")
        val values = intArrayOf(90, 270, 0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setItems(labels) { _, i ->
                prefs.edit().putInt("rotation", values[i]).apply(); buildScreen()
            }.show()
    }

    private fun chooseAppSize() {
        val values = floatArrayOf(14f, 18f, 22f, 28f, 36f, 44f)
        val labels = arrayOf("Muy pequeño", "Pequeño", "Normal", "Grande", "Muy grande", "Enorme")
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setItems(labels) { _, i ->
                prefs.edit().putFloat("appSize", values[i]).apply(); buildScreen()
            }.show()
    }

    private fun chooseFont() {
        val labels = arrayOf(
            "Sans (predeterminada)", "Sans Light", "Sans Medium",
            "Sans Condensed", "Serif", "Monoespaciada"
        )
        val values = arrayOf(
            "sans-serif", "sans-serif-light", "sans-serif-medium",
            "sans-serif-condensed", "serif", "monospace"
        )
        val current = prefs.getString("fontFamily", "sans-serif")
        val checked = values.indexOf(current).coerceAtLeast(0)
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setSingleChoiceItems(labels, checked) { d, i ->
                prefs.edit().putString("fontFamily", values[i]).apply()
                d.dismiss(); buildScreen()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun chooseBold() {
        val labels = arrayOf("Normal", "Negrita")
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar)
            .setSingleChoiceItems(labels, if (prefs.getBoolean("bold", false)) 1 else 0) { d, i ->
                prefs.edit().putBoolean("bold", i == 1).apply()
                d.dismiss(); buildScreen()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }
}
