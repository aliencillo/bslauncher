package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.pm.ApplicationInfo
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bslauncher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var batteryView: TextView
    private var apps: List<AppEntry> = emptyList()
    private var batteryPercent = 0
    private var isCharging = false
    private var searchVisible = false
    private var downX = 0f
    private var downY = 0f
    private var gestureHandled = false
    private var gestureStarted = false

    private data class AppEntry(val label: String, val packageName: String)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPercent = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (::batteryView.isInitialized) updateBatteryText()
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                gestureHandled = false; gestureStarted = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (!gestureHandled && abs(dx) > dp(42f) && abs(dx) > abs(dy) * 1.35f) {
                    gestureStarted = true
                    if ((dx < 0 && !searchVisible) || (dx > 0 && searchVisible)) {
                        gestureHandled = true
                        if (dx < 0) openSearch() else closeSearch()
                    }
                }
                if (gestureHandled) return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (gestureHandled) { gestureHandled = false; return true }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars()
        loadApps()
        buildScreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        updateInfo()
        window.decorView.post(object : Runnable {
            override fun run() {
                if (isFinishing) return
                updateInfo()
                window.decorView.postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun prefColor(key: String, fallback: Int) = prefs.getInt(key, fallback)

    private fun getFavorites(): MutableSet<String> =
        prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()

    private fun saveFavorites(set: Set<String>) {
        prefs.edit().putStringSet("favorites", set).apply()
    }

    private fun isFavoritesOnly(): Boolean = prefs.getBoolean("favoritesOnly", false)

    private fun setFavoritesOnly(value: Boolean) {
        prefs.edit().putBoolean("favoritesOnly", value).apply()
    }

    private fun applySystemBars() {
        if (prefs.getBoolean("hideStatus", true)) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        }
        window.statusBarColor = prefColor("bg", Color.BLACK)
        window.navigationBarColor = prefColor("bg", Color.BLACK)
        window.decorView.systemUiVisibility = 0
    }

    private fun loadApps() {
        val pm = packageManager
        apps = pm.getInstalledApplications(0).mapNotNull { info ->
            if (info.packageName == packageName) return@mapNotNull null
            val launch = pm.getLaunchIntentForPackage(info.packageName) ?: return@mapNotNull null
            AppEntry(pm.getApplicationLabel(info).toString(), info.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    private fun makeText(value: String, size: Float, color: Int = prefColor("text", Color.WHITE)): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = Typeface.create("sans-serif", if (prefs.getBoolean("bold", false)) Typeface.BOLD else Typeface.NORMAL)
            includeFontPadding = false
        }

    private fun buildScreen() {
        applySystemBars()
        val bg = prefColor("bg", Color.BLACK)
        // Márgenes fijos: evita que las apps lleguen a los bordes superior/inferior
        val padH = dp(20f)
        val padV = dp(16f)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(padH, padV, padH, padV)
        }

        val layoutMode = prefs.getInt("rotation", 90) // 90 lateral, 270 invertido, 0 superior

        val body = LinearLayout(this).apply {
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }

        // Columna de apps (izquierda o debajo)
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        search = EditText(this).apply {
            hint = "Buscar aplicaciones"
            setHintTextColor(Color.GRAY)
            setTextColor(prefColor("text", Color.WHITE))
            textSize = 17f
            setSingleLine(true)
            isFocusableInTouchMode = true
            background = null
            setPadding(0, dp(8f), 0, dp(8f))
            visibility = if (searchVisible) View.VISIBLE else View.GONE
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        left.addView(search, LinearLayout.LayoutParams(-1, dp(48f)))

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            isFillViewport = true
        }
        appList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
        }
        scroll.addView(appList, android.widget.FrameLayout.LayoutParams(-1, -2))
        left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Bloque informativo (reloj + fecha + batería) — siempre visible
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        clockView = makeText("00:00", prefs.getFloat("clockSize", 30f)).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        dateView = makeText("01/01 LU", prefs.getFloat("dateSize", 12f)).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        batteryView = makeText("--%", prefs.getFloat("batterySize", 12f)).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }

        val infoContent = LinearLayout(this).apply {
            // En modos laterales el contenido interno es horizontal para que al rotar 90° quede vertical
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        infoContent.addView(clockView, spacedParams(layoutMode == 0))
        infoContent.addView(dateView, spacedParams(layoutMode == 0))
        infoContent.addView(batteryView, spacedParams(layoutMode == 0))

        // Rotación del bloque:
        //  90  → lateral (derecha): girar 90°  (texto vertical)
        // 270  → lateral invertido: girar 270° / -90°
        //  0   → superior: sin rotación
        when (layoutMode) {
            90  -> infoContent.rotation = 90f
            270 -> infoContent.rotation = 270f
            else -> infoContent.rotation = 0f
        }
        info.addView(infoContent)
        info.setOnLongClickListener { showSettings(); true }

        // Permite desplazar el listado deslizando sobre la columna del bloque informativo
        var infoTouchStartY = 0f
        var infoTouchLastY = 0f
        var infoScrollActive = false
        val touchSlop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        info.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    infoTouchStartY = event.y
                    infoTouchLastY = event.y
                    infoScrollActive = false
                    false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!infoScrollActive && abs(event.y - infoTouchStartY) > touchSlop) {
                        infoScrollActive = true
                    }
                    if (infoScrollActive) {
                        val delta = (infoTouchLastY - event.y).toInt()
                        scroll.scrollBy(0, delta)
                        infoTouchLastY = event.y
                    }
                    infoScrollActive
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val consumed = infoScrollActive
                    infoScrollActive = false
                    consumed
                }
                else -> infoScrollActive
            }
        }

        if (layoutMode == 0) {
            // Superior: bloque arriba, apps debajo (todas visibles)
            body.addView(info, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18f) })
            body.addView(left, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            // Lateral / lateral invertido: apps a la izquierda (~72 %), bloque a la derecha
            left.layoutParams = LinearLayout.LayoutParams(0, -1, 72f)
            info.layoutParams = LinearLayout.LayoutParams(0, -1, 28f)
            body.addView(left)
            body.addView(info)
        }
        root.addView(body)
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")
        // Pulsación larga solo en zonas vacías / bloque informativo para abrir ajustes.
        // No se usa sobre las aplicaciones (no hay favoritos ni acciones de añadir/quitar).
        root.setOnLongClickListener { showSettings(); true }
        if (searchVisible) showKeyboard()
    }

    private fun spacedParams(vertical: Boolean): LinearLayout.LayoutParams =
        if (vertical) LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12f) }
        else LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(12f) }

    private fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        search.visibility = View.VISIBLE
        search.alpha = 0f
        search.translationX = -dp(22f).toFloat()
        search.animate().alpha(1f).translationX(0f).setDuration(260)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).withEndAction {
                if (searchVisible) showKeyboard()
            }.start()
        search.requestFocus()
    }

    private fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(search.windowToken, 0)
        search.animate().alpha(0f).translationX(-dp(22f).toFloat()).setDuration(210)
            .setInterpolator(android.view.animation.AccelerateInterpolator()).withEndAction {
                if (!searchVisible) {
                    search.setText("")
                    search.clearFocus()
                    search.visibility = View.GONE
                    search.alpha = 1f
                    search.translationX = 0f
                    renderApps("")
                }
            }.start()
    }

    private fun showKeyboard() {
        search.post {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val favs = getFavorites()
        val q = query.trim()
        val matches = apps.filter { app ->
            val nameOk = q.isEmpty() || app.label.contains(q, true)
            val favOk = !isFavoritesOnly() || favs.contains(app.packageName)
            nameOk && favOk
        }
        matches.forEach { app ->
            val label = makeText(app.label, prefs.getFloat("appSize", 22f)).apply {
                // Separación fija entre aplicaciones
                val spacing = dp(10f)
                setPadding(0, spacing, 0, spacing)
                setOnClickListener { packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) } }
                // No acciones de favoritos ni menú contextual en pulsación larga.
                setOnLongClickListener { true }
            }
            appList.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateInfo() {
        if (!::clockView.isInitialized) return
        val now = Date()
        val mode = prefs.getInt("rotation", 90)
        clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        val spanish = Locale("es", "ES")
        dateView.text = if (mode == 0) {
            SimpleDateFormat("EEEE, d 'de' MMMM", spanish).format(now).lowercase(spanish)
        } else {
            val day = SimpleDateFormat("dd", spanish).format(now)
            val month = SimpleDateFormat("MM", spanish).format(now)
            val weekday = SimpleDateFormat("EE", spanish).format(now).replace(".", "").take(2).uppercase(spanish)
            "$day/$month $weekday"
        }
        updateBatteryText()
    }

    private fun updateBatteryText() {
        if (!::batteryView.isInitialized) return
        val label = if (isCharging) "● $batteryPercent%" else "$batteryPercent%"
        val styled = SpannableString(label)
        if (isCharging) styled.setSpan(
            ForegroundColorSpan(Color.rgb(32, 190, 125)), 0, 1,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        batteryView.text = styled
    }

    private fun showSettings() {
        val options = arrayOf(
            "Color del texto",
            "Color del fondo",
            "Fecha / Hora / Batería",
            "Tamaño del texto de aplicaciones",
            "Grosor de letra",
            "Ocultar / mostrar barra superior del sistema",
            "Aplicaciones",
            "Volver a cargar aplicaciones"
        )
        AlertDialog.Builder(this).setTitle("BSLauncher · Ajustes").setItems(options) { _, which ->
            when (which) {
                0 -> chooseColor("text", "Color del texto")
                1 -> chooseColor("bg", "Color del fondo")
                2 -> chooseRotation()
                3 -> chooseAppSize()
                4 -> chooseBold()
                5 -> { prefs.edit().putBoolean("hideStatus", !prefs.getBoolean("hideStatus", true)).apply(); buildScreen() }
                6 -> showAppsSettings()
                7 -> { loadApps(); renderApps(search.text.toString()) }
            }
        }.setNegativeButton("Cerrar", null).show()
    }

    private fun showAppsSettings() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(12f), dp(20f), dp(8f))
        }

        // Selector Mostrar todos / Mostrar favoritos
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val modeLabel = TextView(this).apply {
            text = if (isFavoritesOnly()) "Mostrar favoritos" else "Mostrar todos"
            setTextColor(Color.WHITE)
            textSize = 16f
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val modeBtn = TextView(this).apply {
            text = "Cambiar"
            setTextColor(Color.rgb(130, 180, 255))
            textSize = 15f
            setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
            setOnClickListener {
                val next = !isFavoritesOnly()
                setFavoritesOnly(next)
                modeLabel.text = if (next) "Mostrar favoritos" else "Mostrar todos"
                renderApps(search.text.toString())
                Toast.makeText(this@MainActivity, if (next) "Solo favoritos" else "Todas las apps", Toast.LENGTH_SHORT).show()
            }
        }
        modeRow.addView(modeLabel)
        modeRow.addView(modeBtn)
        outer.addView(modeRow)

        val separator = View(this).apply {
            setBackgroundColor(Color.GRAY)
            layoutParams = LinearLayout.LayoutParams(-1, 1).apply {
                topMargin = dp(12f)
                bottomMargin = dp(12f)
            }
        }
        outer.addView(separator)

        val listTitle = TextView(this).apply {
            text = "Seleccionar favoritos"
            setTextColor(Color.LTGRAY)
            textSize = 13f
            setPadding(0, 0, 0, dp(8f))
        }
        outer.addView(listTitle)

        val favs = getFavorites()
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(320f))
        }
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6f), 0, dp(6f))
            }
            val cb = CheckBox(this).apply {
                isChecked = favs.contains(app.packageName)
                setOnCheckedChangeListener { _, checked ->
                    val current = getFavorites()
                    if (checked) current.add(app.packageName) else current.remove(app.packageName)
                    saveFavorites(current)
                    if (isFavoritesOnly()) renderApps(search.text.toString())
                }
            }
            val name = TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 15f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { cb.isChecked = !cb.isChecked }
            }
            row.addView(cb)
            row.addView(name)
            list.addView(row)
        }
        scroll.addView(list)
        outer.addView(scroll)

        AlertDialog.Builder(this)
            .setTitle("Aplicaciones")
            .setView(outer)
            .setPositiveButton("Listo") { _, _ -> renderApps(search.text.toString()) }
            .show()
    }

    private fun chooseColor(key: String, title: String) {
        val labels = arrayOf("Negro", "Blanco", "Gris claro", "Gris", "Verde suave", "Azul suave")
        val values = intArrayOf(Color.BLACK, Color.WHITE, Color.LTGRAY, Color.GRAY, Color.rgb(130, 220, 170), Color.rgb(130, 180, 255))
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i ->
            prefs.edit().putInt(key, values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseRotation() {
        val labels = arrayOf("Lateral", "Lateral invertido 180°", "Superior")
        val values = intArrayOf(90, 270, 0)
        AlertDialog.Builder(this).setTitle("Fecha / Hora / Batería").setItems(labels) { _, i ->
            prefs.edit().putInt("rotation", values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseAppSize() = chooseFloat("Tamaño del texto", "appSize", floatArrayOf(16f, 19f, 22f, 26f, 30f), arrayOf("Muy pequeño", "Pequeño", "Normal", "Grande", "Muy grande"))

    private fun chooseBold() {
        val labels = arrayOf("Normal", "Negrita")
        AlertDialog.Builder(this).setTitle("Grosor de letra").setSingleChoiceItems(labels, if (prefs.getBoolean("bold", false)) 1 else 0) { d, i ->
            prefs.edit().putBoolean("bold", i == 1).apply(); d.dismiss(); buildScreen()
        }.setNegativeButton("Cancelar", null).show()
    }

    private fun chooseFloat(title: String, key: String, values: FloatArray, labels: Array<String>) {
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i -> prefs.edit().putFloat(key, values[i]).apply(); buildScreen() }.show()
    }

}
