package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var search: EditText
    private lateinit var appList: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var battery: TextView
    private lateinit var batteryDot: View
    private lateinit var chargingBadge: TextView
    private var allApps: List<AppEntry> = emptyList()
    private var batteryPct = 0
    private var charging = false

    data class AppEntry(val label: String, val packageName: String)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPct = (level * 100) / scale
            charging = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) in
                listOf(BatteryManager.BATTERY_STATUS_CHARGING, BatteryManager.BATTERY_STATUS_FULL)
            updateBattery()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        loadApps()
        buildHome()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        updateClock()
        android.os.Handler(mainLooper).post(object : Runnable {
            override fun run() { updateClock(); android.os.Handler(mainLooper).postDelayed(this, 1000) }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(v: Float) = (v * resources.displayMetrics.density).toInt()
    private fun color(key: String, fallback: Int) = prefs.getInt(key, fallback)

    private fun loadApps() {
        val pm = packageManager
        allApps = pm.getInstalledApplications(0).mapNotNull { info ->
            val launch = pm.getLaunchIntentForPackage(info.packageName) ?: return@mapNotNull null
            val label = pm.getApplicationLabel(info).toString()
            if (info.packageName == packageName) null else AppEntry(label, info.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    private fun text(value: String, size: Float, color: Int = Color.WHITE): TextView =
        TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            includeFontPadding = false
        }

    private fun buildHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(color("bg", Color.BLACK))
            setPadding(dp(22f), dp(12f), dp(14f), dp(8f))
        }
        val top = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(18f))
        }
        val topPill = View(this).apply {
            setBackgroundColor(Color.rgb(35,35,35))
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(35,35,35)); cornerRadius = dp(5f).toFloat()
            }
            layoutParams = FrameLayout.LayoutParams(dp(48f), dp(4f), Gravity.CENTER)
        }
        chargingBadge = text("CARGANDO", 9f, Color.rgb(52,211,153)).apply {
            letterSpacing = .18f
            visibility = View.GONE
            layoutParams = FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.CENTER_VERTICAL)
        }
        top.addView(topPill); top.addView(chargingBadge)
        root.addView(top)

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, 0, 74f).apply { height = 0; weight = 74f }
        }
        search = EditText(this).apply {
            hint = "Buscar..."
            setHintTextColor(Color.rgb(90,90,90))
            setTextColor(Color.WHITE)
            textSize = 14f
            setSingleLine(true)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT)
                setStroke(dp(1f), Color.rgb(28,28,28))
            }
            setPadding(0, dp(8f), dp(8f), dp(8f))
        }
        left.addView(search, LinearLayout.LayoutParams(-1, dp(44f)).apply { bottomMargin = dp(10f) })
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false }
        appList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0,0,dp(8f),dp(12f)) }
        scroll.addView(appList)
        left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(10f), 0, 0)
            setOnLongClickListener { showSettings(); true }
        }
        val count = text("${allApps.size} apps", 10f, Color.rgb(100,100,100))
        footer.addView(count)
        val az = text("   •   A–Z", 10f, Color.rgb(100,100,100)).apply {
            setOnClickListener { search.setText(""); renderApps("") }
        }
        footer.addView(az)
        left.addView(footer, LinearLayout.LayoutParams(-1, dp(30f)))

        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.TRANSPARENT); setStroke(dp(1f), Color.rgb(18,18,18))
            }
            layoutParams = LinearLayout.LayoutParams(0, -1, 26f)
        }
        val verticalBlock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        clock = text("00:00", 38f)
        date = text("LUN, 23 NOV", 11f, Color.LTGRAY).apply { letterSpacing = .16f }
        batteryDot = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.WHITE)
            }
            layoutParams = LinearLayout.LayoutParams(dp(6f), dp(6f))
        }
        battery = text("85%", 11f, Color.LTGRAY)
        verticalBlock.addView(clock)
        verticalBlock.addView(text("   •   ", 16f, Color.DKGRAY))
        verticalBlock.addView(date)
        verticalBlock.addView(text("   •   ", 16f, Color.DKGRAY))
        verticalBlock.addView(batteryDot)
        verticalBlock.addView(battery)
        val rotation = prefs.getFloat("rotation", 90f)
        verticalBlock.rotation = rotation
        right.addView(verticalBlock)
        right.setOnLongClickListener { showSettings(); true }

        body.addView(left, LinearLayout.LayoutParams(0, -1, 74f))
        body.addView(right, LinearLayout.LayoutParams(0, -1, 26f))
        root.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))

        val bottom = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(28f))
            setOnClickListener { search.setText(""); scrollToTop() }
            setOnLongClickListener { showSettings(); true }
        }
        val pill = View(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.rgb(55,55,55)); cornerRadius = dp(4f).toFloat()
            }
            layoutParams = FrameLayout.LayoutParams(dp(112f), dp(4f), Gravity.CENTER)
        }
        bottom.addView(pill)
        root.addView(bottom)
        setContentView(root)
        renderApps("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.setOnClickListener { /* intentionally quiet */ }
    }

    private fun scrollToTop() { search.clearFocus() }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val matches = allApps.filter { it.label.contains(query.trim(), true) }
        matches.forEach { app ->
            val item = text(app.label, prefs.getFloat("appSize", 22f), color("text", Color.WHITE)).apply {
                setPadding(0, dp(prefs.getInt("spacing", 10).toFloat()), 0, dp(prefs.getInt("spacing", 10).toFloat()))
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                    if (launch != null) startActivity(launch)
                }
            }
            appList.addView(item, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateClock() {
        if (!::clock.isInitialized) return
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEE, d MMM", Locale("es", "ES")).format(now).uppercase(Locale("es","ES")).replace(".", "")
    }

    private fun updateBattery() {
        if (!::battery.isInitialized) return
        battery.text = "$batteryPct%"
        chargingBadge.visibility = if (charging) View.VISIBLE else View.GONE
        val c = when { charging -> Color.rgb(52,211,153); batteryPct <= 15 -> Color.RED; batteryPct <= 30 -> Color.YELLOW; else -> Color.WHITE }
        (batteryDot.background as? android.graphics.drawable.GradientDrawable)?.setColor(c)
    }

    private fun showSettings() {
        val options = arrayOf("Rotación reloj/fecha/batería", "Tamaño texto aplicaciones", "Separación entre aplicaciones",
            "Color del texto", "Color de fondo", "Mostrar configuración de inicio")
        AlertDialog.Builder(this).setTitle("Personalización").setItems(options) { _, which ->
            when (which) {
                0 -> chooseRotation()
                1 -> chooseSize()
                2 -> chooseSpacing()
                3 -> chooseColor("text", "Color del texto")
                4 -> chooseColor("bg", "Color de fondo")
                5 -> showDefaultLauncherHelp()
            }
        }.setNegativeButton("Cerrar", null).show()
    }

    private fun chooseRotation() {
        val labels = arrayOf("90° (como el diseño original)", "270° (sentido contrario)", "0° (horizontal)")
        val values = floatArrayOf(90f, 270f, 0f)
        AlertDialog.Builder(this).setTitle("Rotación del bloque").setItems(labels) { _, i ->
            prefs.edit().putFloat("rotation", values[i]).apply()
            buildHome()
        }.show()
    }

    private fun chooseSize() {
        val values = arrayOf("Pequeño", "Original", "Grande")
        val sizes = floatArrayOf(18f, 22f, 26f)
        AlertDialog.Builder(this).setTitle("Tamaño de aplicaciones").setItems(values) { _, i ->
            prefs.edit().putFloat("appSize", sizes[i]).apply(); buildHome()
        }.show()
    }

    private fun chooseSpacing() {
        val labels = arrayOf("Compacta", "Original", "Amplia")
        val values = intArrayOf(4, 10, 17)
        AlertDialog.Builder(this).setTitle("Separación").setItems(labels) { _, i ->
            prefs.edit().putInt("spacing", values[i]).apply(); buildHome()
        }.show()
    }

    private fun chooseColor(key: String, title: String) {
        val labels = arrayOf("Blanco", "Gris claro", "Gris", "Verde suave", "Azul suave")
        val values = intArrayOf(Color.WHITE, Color.LTGRAY, Color.GRAY, Color.rgb(130,220,170), Color.rgb(130,180,255))
        AlertDialog.Builder(this).setTitle(title).setItems(labels) { _, i ->
            prefs.edit().putInt(key, values[i]).apply(); buildHome()
        }.show()
    }

    private fun showDefaultLauncherHelp() {
        AlertDialog.Builder(this).setTitle("Launcher predeterminado")
            .setMessage("Abre Ajustes de Android > Aplicaciones > Aplicaciones predeterminadas > Aplicación de inicio y selecciona Launcher Minimalista.")
            .setPositiveButton("Entendido", null).show()
    }
}
