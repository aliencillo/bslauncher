package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.os.BatteryManager
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import android.text.SpannableString
import android.text.style.ForegroundColorSpan
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("bslauncher", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private lateinit var appList: LinearLayout
    private lateinit var search: EditText
    private lateinit var clockView: TextView
    private lateinit var dateView: TextView
    private lateinit var batteryView: TextView
    private var apps: List<AppEntry> = emptyList()
    private var batteryPercent = 0
    private var isCharging = false
    private var searchVisible = false
    private var downX = 0f
    private var downY = 0f
    private var gestureHandled = false
    private var gestureStarted = false

    private data class AppEntry(val label: String, val packageName: String)

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent ?: return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
            batteryPercent = level * 100 / scale
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL
            if (::batteryView.isInitialized) updateBatteryText()
        }
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                gestureHandled = false; gestureStarted = false
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.x - downX
                val dy = event.y - downY
                if (!gestureHandled && abs(dx) > dp(42f) && abs(dx) > abs(dy) * 1.35f) {
                    gestureStarted = true
                    if ((dx < 0 && !searchVisible) || (dx > 0 && searchVisible)) {
                        gestureHandled = true
                        if (dx < 0) openSearch() else closeSearch()
                    }
                }
                if (gestureHandled) return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (gestureHandled) { gestureHandled = false; return true }
            }
        }
        return super.dispatchTouchEvent(event)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applySystemBars()
        loadApps()
        buildScreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        updateInfo()
        window.decorView.post(object : Runnable {
            override fun run() {
                if (isFinishing) return
                updateInfo()
                window.decorView.postDelayed(this, 1000)
            }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    private fun prefColor(key: String, fallback: Int) = prefs.getInt(key, fallback)

    private fun getFavorites(): MutableSet<String> =
        prefs.getStringSet("favorites", emptySet())?.toMutableSet() ?: mutableSetOf()

    private fun saveFavorites(set: Set<String>) {
        prefs.edit().putStringSet("favorites", set).apply()
    }

    private fun isFavoritesOnly(): Boolean = prefs.getBoolean("favoritesOnly", false)

    private fun setFavoritesOnly(value: Boolean) {
        prefs.edit().putBoolean("favoritesOnly", value).apply()
    }

    private fun currentTypeface(): Typeface {
        val family = prefs.getString("fontFamily", "sans-serif") ?: "sans-serif"
        val style = if (prefs.getBoolean("bold", false)) Typeface.BOLD else Typeface.NORMAL
        return Typeface.create(family, style)
    }

    private fun applySystemBars() {
        val hide = prefs.getBoolean("hideStatus", true)
        if (hide) {
            window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        window.statusBarColor = prefColor("bg", Color.BLACK)
        window.navigationBarColor = prefColor("bg", Color.BLACK)
    }

    private fun loadApps() {
        val pm = packageManager
        apps = pm.getInstalledApplications(0).mapNotNull { info ->
            if (info.packageName == packageName) return@mapNotNull null
            pm.getLaunchIntentForPackage(info.packageName) ?: return@mapNotNull null
            AppEntry(pm.getApplicationLabel(info).toString(), info.packageName)
        }.distinctBy { it.packageName }.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.label })
    }

    private fun makeText(value: String, size: Float, color: Int = prefColor("text", Color.WHITE)): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            typeface = currentTypeface()
            includeFontPadding = false
        }

    private fun buildScreen() {
        applySystemBars()
        val bg = prefColor("bg", Color.BLACK)
        // Márgenes amplios fijos para no solaparse con barras del sistema
        val padH = dp(22f)
        val padTop = dp(28f)
        val padBottom = dp(28f)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(padH, padTop, padH, padBottom)
        }

        val layoutMode = prefs.getInt("rotation", 90) // 90 lateral, 270 invertido, 0 superior

        val body = LinearLayout(this).apply {
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(-1, 0, 1f)
        }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        search = EditText(this).apply {
            hint = "Buscar..."
            setHintTextColor(Color.GRAY)
            setTextColor(prefColor("text", Color.WHITE))
            textSize = 17f
            typeface = currentTypeface()
            setSingleLine(true)
            isFocusableInTouchMode = true
            background = null
            setPadding(0, dp(6f), 0, dp(6f))
            visibility = if (searchVisible) View.VISIBLE else View.GONE
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
        }
        left.addView(search, LinearLayout.LayoutParams(-1, dp(44f)))

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            isFillViewport = true
        }
        appList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (layoutMode == 0) Gravity.TOP else Gravity.CENTER_VERTICAL
        }
        scroll.addView(appList, android.widget.FrameLayout.LayoutParams(-1, -2))
        left.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Bloque informativo — siempre visible
        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = if (layoutMode == 0) (Gravity.START or Gravity.TOP) else Gravity.CENTER
        }

        val clockSize = prefs.getFloat("clockSize", 36f)
        val dateSize = prefs.getFloat("dateSize", 13f)
        val batSize = prefs.getFloat("batterySize", 13f)

        clockView = makeText("00:00", clockSize).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        dateView = makeText("MAR, 24 NOV", dateSize).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }
        batteryView = makeText("97%", batSize).apply {
            gravity = Gravity.CENTER
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }

        // Contenido interno: en lateral es HORIZONTAL para que al girar 90° quede en una sola columna vertical
        val infoContent = LinearLayout(this).apply {
            orientation = if (layoutMode == 0) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            gravity = if (layoutMode == 0) (Gravity.START or Gravity.CENTER_VERTICAL) else Gravity.CENTER
        }

        val gap = if (layoutMode == 0) {
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6f) }
        } else {
            LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(14f) }
        }

        infoContent.addView(clockView, if (layoutMode == 0) LinearLayout.LayoutParams(-2, -2) else gap.also { it.leftMargin = 0 })
        infoContent.addView(dateView, gap)
        infoContent.addView(batteryView, gap)

        when (layoutMode) {
            90  -> infoContent.rotation = 90f
            270 -> infoContent.rotation = 270f
            else -> infoContent.rotation = 0f
        }
        info.addView(infoContent)

        // Scroll del listado desde la columna del reloj
        var infoTouchStartY = 0f
        var infoTouchLastY = 0f
        var infoScrollActive = false
        val touchSlop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        info.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    infoTouchStartY = event.y; infoTouchLastY = event.y; infoScrollActive = false; false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!infoScrollActive && abs(event.y - infoTouchStartY) > touchSlop) infoScrollActive = true
                    if (infoScrollActive) {
                        scroll.scrollBy(0, (infoTouchLastY - event.y).toInt())
                        infoTouchLastY = event.y
                    }
                    infoScrollActive
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val c = infoScrollActive; infoScrollActive = false; c
                }
                else -> infoScrollActive
            }
        }

        if (layoutMode == 0) {
            // Superior: bloque arriba alineado a la izquierda, con margen, apps debajo
            info.setPadding(0, dp(4f), 0, dp(12f))
            body.addView(info, LinearLayout.LayoutParams(-1, -2))
            body.addView(left, LinearLayout.LayoutParams(-1, 0, 1f))
        } else {
            left.layoutParams = LinearLayout.LayoutParams(0, -1, 70f)
            info.layoutParams = LinearLayout.LayoutParams(0, -1, 30f)
            body.addView(left)
            body.addView(info)
        }
        root.addView(body)
        setContentView(root)

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")

        // Pulsación larga en TODA la pantalla abre ajustes
        val openCfg = View.OnLongClickListener { showSettings(); true }
        root.setOnLongClickListener(openCfg)
        scroll.setOnLongClickListener(openCfg)
        appList.setOnLongClickListener(openCfg)
        info.setOnLongClickListener(openCfg)
        left.setOnLongClickListener(openCfg)

        if (searchVisible) showKeyboard()
    }

    private fun openSearch() {
        if (searchVisible) return
        searchVisible = true
        search.visibility = View.VISIBLE
        search.alpha = 0f
        search.translationY = -dp(12f).toFloat()
        search.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(320)
            .setInterpolator(android.view.animation.DecelerateInterpolator(1.5f))
            .withEndAction { if (searchVisible) showKeyboard() }
            .start()
        search.requestFocus()
    }

    private fun closeSearch() {
        if (!searchVisible) return
        searchVisible = false
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        search.animate()
            .alpha(0f)
            .translationY(-dp(12f).toFloat())
            .setDuration(260)
            .setInterpolator(android.view.animation.AccelerateInterpolator(1.2f))
            .withEndAction {
                if (!searchVisible) {
                    search.setText("")
                    search.clearFocus()
                    search.visibility = View.GONE
                    search.alpha = 1f
                    search.translationY = 0f
                    renderApps("")
                }
            }.start()
    }

    private fun showKeyboard() {
        search.post {
            search.requestFocus()
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
                .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
        }
    }

    private fun renderApps(query: String) {
        if (!::appList.isInitialized) return
        appList.removeAllViews()
        val favs = getFavorites()
        val q = query.trim()
        val matches = apps.filter { app ->
            val nameOk = q.isEmpty() || app.label.contains(q, true)
            val favOk = !isFavoritesOnly() || favs.contains(app.packageName)
            nameOk && favOk
        }
        val appSize = prefs.getFloat("appSize", 22f)
        val spacing = dp(10f)
        matches.forEach { app ->
            val label = makeText(app.label, appSize).apply {
                setPadding(0, spacing, 0, spacing)
                setOnClickListener {
                    packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
                }
                // No favoritos por long-press
                setOnLongClickListener { showSettings(); true }
            }
            appList.addView(label, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun updateInfo() {
        if (!::clockView.isInitialized) return
        val now = Date()
        val mode = prefs.getInt("rotation", 90)
        clockView.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        val spanish = Locale("es", "ES")
        dateView.text = if (mode == 0) {
            // Superior: fecha completa
            SimpleDateFormat("EEEE, d 'de' MMMM", spanish).format(now).lowercase(spanish)
        } else {
            // Lateral: estilo de la captura → "MAR, 24 NOV"
            val weekday = SimpleDateFormat("EEE", spanish).format(now).replace(".", "").uppercase(spanish).take(3)
            val day = SimpleDateFormat("d", spanish).format(now)
            val month = SimpleDateFormat("MMM", spanish).format(now).replace(".", "").uppercase(spanish).take(3)
            "$weekday, $day $month"
        }
        updateBatteryText()
    }

    private fun updateBatteryText() {
        if (!::batteryView.isInitialized) return
        // Siempre mostrar porcentaje; punto verde solo si está cargando
        val label = if (isCharging) "● $batteryPercent%" else "$batteryPercent%"
        val styled = SpannableString(label)
        if (isCharging) {
            styled.setSpan(
                ForegroundColorSpan(Color.rgb(32, 190, 125)),
                0, 1,
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        batteryView.text = styled
        batteryView.visibility = View.VISIBLE
    }

    // ─── Diálogos minimalistas monocromos ────────────────────────────────

    private fun monoDialog(): AlertDialog.Builder {
        val builder = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog)
        return builder
    }

    private fun showSettings() {
        val options = arrayOf(
            "Color del texto",
            "Color del fondo",
            "Fecha / Hora / Batería",
            "Tamaño del texto",
            "Tipo de letra",
            "Grosor de letra",
            "Ocultar / mostrar barra del sistema",
            "Aplicaciones",
            "Volver a cargar aplicaciones"
        )
        monoDialog()
            .setTitle("Ajustes")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> chooseColor("text", "Color del texto")
                    1 -> chooseColor("bg", "Color del fondo")
                    2 -> chooseRotation()
                    3 -> chooseAppSize()
                    4 -> chooseFont()
                    5 -> chooseBold()
                    6 -> {
                        prefs.edit().putBoolean("hideStatus", !prefs.getBoolean("hideStatus", true)).apply()
                        buildScreen()
                    }
                    7 -> showAppsSettings()
                    8 -> { loadApps(); renderApps(search.text.toString()) }
                }
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun showAppsSettings() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20f), dp(12f), dp(20f), dp(8f))
            setBackgroundColor(Color.BLACK)
        }

        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val modeLabel = TextView(this).apply {
            text = if (isFavoritesOnly()) "Mostrar favoritos" else "Mostrar todos"
            setTextColor(Color.WHITE)
            textSize = 16f
            typeface = currentTypeface()
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val modeBtn = TextView(this).apply {
            text = "Cambiar"
            setTextColor(Color.LTGRAY)
            textSize = 15f
            setPadding(dp(12f), dp(8f), dp(12f), dp(8f))
            setOnClickListener {
                val next = !isFavoritesOnly()
                setFavoritesOnly(next)
                modeLabel.text = if (next) "Mostrar favoritos" else "Mostrar todos"
                renderApps(search.text.toString())
                Toast.makeText(this@MainActivity, if (next) "Solo favoritos" else "Todas las apps", Toast.LENGTH_SHORT).show()
            }
        }
        modeRow.addView(modeLabel)
        modeRow.addView(modeBtn)
        outer.addView(modeRow)

        val separator = View(this).apply {
            setBackgroundColor(Color.DKGRAY)
            layoutParams = LinearLayout.LayoutParams(-1, 1).apply {
                topMargin = dp(12f); bottomMargin = dp(12f)
            }
        }
        outer.addView(separator)

        val listTitle = TextView(this).apply {
            text = "Seleccionar favoritos"
            setTextColor(Color.GRAY)
            textSize = 13f
            setPadding(0, 0, 0, dp(8f))
        }
        outer.addView(listTitle)

        val favs = getFavorites()
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(320f))
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6f), 0, dp(6f))
            }
            val cb = CheckBox(this).apply {
                isChecked = favs.contains(app.packageName)
                setOnCheckedChangeListener { _, checked ->
                    val current = getFavorites()
                    if (checked) current.add(app.packageName) else current.remove(app.packageName)
                    saveFavorites(current)
                    if (isFavoritesOnly()) renderApps(search.text.toString())
                }
            }
            val name = TextView(this).apply {
                text = app.label
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = currentTypeface()
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { cb.isChecked = !cb.isChecked }
            }
            row.addView(cb)
            row.addView(name)
            list.addView(row)
        }
        scroll.addView(list)
        outer.addView(scroll)

        monoDialog()
            .setTitle("Aplicaciones")
            .setView(outer)
            .setPositiveButton("Listo") { _, _ -> renderApps(search.text.toString()) }
            .show()
    }

    private fun chooseColor(key: String, title: String) {
        val labels = arrayOf("Negro", "Blanco", "Gris claro", "Gris", "Verde suave", "Azul suave")
        val values = intArrayOf(
            Color.BLACK, Color.WHITE, Color.LTGRAY, Color.GRAY,
            Color.rgb(130, 220, 170), Color.rgb(130, 180, 255)
        )
        monoDialog().setTitle(title).setItems(labels) { _, i ->
            prefs.edit().putInt(key, values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseRotation() {
        val labels = arrayOf("Lateral", "Lateral invertido", "Superior")
        val values = intArrayOf(90, 270, 0)
        monoDialog().setTitle("Fecha / Hora / Batería").setItems(labels) { _, i ->
            prefs.edit().putInt("rotation", values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseAppSize() {
        // Rango más amplio para que el cambio se note claramente
        val values = floatArrayOf(14f, 18f, 22f, 28f, 36f, 44f)
        val labels = arrayOf("Muy pequeño", "Pequeño", "Normal", "Grande", "Muy grande", "Enorme")
        monoDialog().setTitle("Tamaño del texto").setItems(labels) { _, i ->
            prefs.edit().putFloat("appSize", values[i]).apply(); buildScreen()
        }.show()
    }

    private fun chooseFont() {
        val labels = arrayOf(
            "Sans (predeterminada)",
            "Sans Light",
            "Sans Medium",
            "Sans Condensed",
            "Serif",
            "Monoespaciada"
        )
        val values = arrayOf(
            "sans-serif",
            "sans-serif-light",
            "sans-serif-medium",
            "sans-serif-condensed",
            "serif",
            "monospace"
        )
        val current = prefs.getString("fontFamily", "sans-serif")
        val checked = values.indexOf(current).coerceAtLeast(0)
        monoDialog().setTitle("Tipo de letra")
            .setSingleChoiceItems(labels, checked) { d, i ->
                prefs.edit().putString("fontFamily", values[i]).apply()
                d.dismiss()
                buildScreen()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    private fun chooseBold() {
        val labels = arrayOf("Normal", "Negrita")
        monoDialog().setTitle("Grosor de letra")
            .setSingleChoiceItems(labels, if (prefs.getBoolean("bold", false)) 1 else 0) { d, i ->
                prefs.edit().putBoolean("bold", i == 1).apply()
                d.dismiss()
                buildScreen()
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }
}
