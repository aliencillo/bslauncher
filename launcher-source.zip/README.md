# BSLauncher 1.2

Launcher Android minimalista (Android 10+, API 29).

- HOME y LAUNCHER con icono propio.
- Fondo y texto configurables, incluido negro puro para ambos.
- Interfaz de solo fondo y texto: sin tarjetas, líneas decorativas ni iconos en la lista.
- Márgenes fijos arriba/abajo/lados para que ninguna aplicación llegue a los bordes.
- Buscador oculto; gesto horizontal con transición suave, foco y teclado al entrar, cierre suave al volver.
- Lista de aplicaciones instaladas con lanzamiento directo.
- **Favoritos**: Ajustes → Aplicaciones (sin usar pulsación larga).
  - Opción **Mostrar todos / Mostrar favoritos**.
  - Lista de todas las apps con casillas para marcar/desmarcar.
  - La selección se guarda aunque se cierre la aplicación.
- Tres disposiciones del bloque informativo:
  - **Lateral**: reloj, fecha y batería verticales (girados 90°) a la derecha.
  - **Lateral invertido 180°**: orientación correspondiente.
  - **Superior**: bloque arriba y todas las aplicaciones debajo.
- Fecha compacta en lateral; completa en español en modo superior.
- Batería real, con punto verde mientras carga y actualización automática (siempre visible).
- Tamaño de texto y negrita configurables.
- Barra de estado oculta por defecto (configurable).
- Preferencias persistentes.
- Compatibilidad de actualización (mismo `applicationId`: `com.minimal.launcher`).

## Versión
- versionName: **1.2**
- versionCode: **4**
- applicationId: `com.minimal.launcher`

## Compilar
JDK 17, Android SDK Platform 35 y Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
