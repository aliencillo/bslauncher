# BSLauncher

Launcher Android minimalista, compatible desde Android 10 (API 29).

## Funciones incluidas
- Actividad de inicio HOME y acceso normal LAUNCHER con icono propio.
- Fondo y texto configurables, incluidos negro puro para ambos.
- Pantalla sin líneas, tarjetas, iconos de apps, contador ni elementos decorativos.
- Buscador oculto al iniciar; deslizar de derecha a izquierda lo muestra, enfoca el campo y solicita el teclado. Deslizar de izquierda a derecha lo cierra.
- Lista de apps instaladas que tienen actividad de lanzamiento.
- Pulsación larga en el nombre de una app para añadir/quitar de favoritos.
- Modo todas las aplicaciones o solo favoritos y gestión múltiple de favoritos en Ajustes.
- Reloj, fecha y batería reales, cada uno ocultable por separado.
- Bloque informativo con orientación 90°, 270° o 0°. En orientación vertical, hora HH/mm en dos líneas y fecha dd/mm/día de semana de dos letras.
- Tamaño de letra, negrita, separación, anchura de columna y márgenes configurables.
- Opción para ocultar/mostrar la barra de estado superior del sistema.
- Preferencias persistentes.
- Mantiene la barra de navegación del sistema; no dibuja una píldora artificial.

## Compilar
Requiere JDK 17, Android SDK Platform 35, Build Tools 35.0.0 y Gradle 8.9.

```bash
gradle --no-daemon assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
