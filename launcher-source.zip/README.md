# BSLauncher 1.3

- Superior: info alineada a la izquierda arriba; lista debajo sin solaparse.
- Al abrir la búsqueda, el campo ocupa su propia fila y empuja la lista.
- Lateral: hora → fecha → batería en una sola línea.
- versionName 1.3 / versionCode 15 / applicationId com.minimal.launcher
