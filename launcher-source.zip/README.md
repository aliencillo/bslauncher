# BSLauncher 1.3

- Márgenes fijos amplios arriba/abajo/lados (la lista no llega a los bordes).
- Superior: info a la izquierda arriba; apps solo debajo, sin mezclarse.
- Lateral: reloj + fecha completa + batería visibles en la columna derecha.
- Clic reloj → reloj. Clic fecha → calendario (varios intents).
- Búsqueda ocupa su fila y empuja la lista.
- versionName 1.3 / versionCode 16 / applicationId com.minimal.launcher
