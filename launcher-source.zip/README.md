# Launcher Minimalista Android

Proyecto Android nativo (Kotlin) que implementa un launcher HOME con interfaz AMOLED minimalista.

## Compilación automática en GitHub Actions

El proyecto incluye `.github/workflows/build-apk.yml` para compilar en la nube sin instalar Android Studio ni el SDK localmente.

1. Sube este proyecto a un repositorio GitHub propio (privado recomendado).
2. Abre **Actions** y ejecuta **Build Android APK** (o espera a que termine el flujo tras subir a `main`).
3. En la ejecución completada, descarga el artefacto `LauncherMinimalistaAndroid-debug-apk`.
4. Descomprime el artefacto y copia el APK al teléfono para instalarlo.

La compilación genera un APK **debug** instalable para pruebas. Para distribuirlo como producto final o publicar actualizaciones consistentes hace falta configurar una clave de firma release.

## Requisitos del proyecto

- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Gradle 8.9
- JDK 17
- compileSdk 35; minSdk 29 (Android 10 o superior)

## Nota sobre el permiso de visibilidad

El manifiesto declara `QUERY_ALL_PACKAGES` para mostrar las aplicaciones instaladas en el cajón del launcher. Google Play restringe este permiso a casos de uso aprobados; para instalación directa fuera de Play Store se puede probar el APK firmado de depuración.
