# BSLauncher 1.3

Launcher Android minimalista (Android 10+, API 29).

- Clic en reloj → app de reloj. Clic en fecha → calendario.
- Multiidioma automático/manual (es, ca, gl, oc, eu, fr, de, it, pt, zh, ja, ru…).
- Fecha siempre larga y localizada.
- Búsqueda sobre todas las apps.
- Favoritos desde Ajustes → Aplicaciones (sin long-press).
- Long-press solo si el dedo no se mueve.
- applicationId: com.minimal.launcher

## Versión
- versionName: **1.3**
- versionCode: **13**
