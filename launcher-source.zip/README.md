# BSLauncher 1.3 – actualización

Código fuente Android (Kotlin), Gradle Kotlin DSL, Android SDK 35, minSdk 29.

## Novedades
- Selector de fondo: recuperados los diez colores originales y conmutador superior derecho entre color plano y modo imagen. Cambiar de lista no modifica el fondo hasta elegir una opción.
- Reloj en ajustes (posición de hora, fecha y batería).
- Traducciones de menús, buscadores y opciones mediante `res/values-*/strings.xml` en español, catalán, gallego, aranés, euskera, inglés, francés, alemán, italiano, portugués, ruso, chino y japonés. Los idiomas regionales usan sus recursos de idioma base.
- Buscar dentro del selector de fuentes y en la gestión de favoritos. El texto y el placeholder de los buscadores utilizan la fuente elegida.
- Desplazamiento elástico también cuando las aplicaciones no llenan la pantalla.
- Cuatro fondos incorporados: fotografía aportada por el usuario como fondo inicial y tres degradados originales creados para este proyecto. Última opción: seleccionar imagen propia.
- Alternar entre lista de texto y rejilla de iconos con nombres desde el menú de ajustes. La preferencia se conserva.

## Compilación
Abrir el directorio en Android Studio con Android SDK 35 instalado, sincronizar Gradle y generar el APK. El paquete no contiene APK ni Gradle Wrapper.

### Build 1.3-19
Import/export all launcher preferences as a versioned JSON document, including custom wallpaper bytes and favorites. Import requires confirmation and replaces existing settings. System fonts must be available on the target device.
