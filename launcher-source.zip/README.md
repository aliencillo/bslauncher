# BSLauncher 1.2

Launcher Android minimalista (Android 10+, API 29).

- HOME y LAUNCHER con icono propio.
- Fondo y texto configurables (incluido negro puro).
- Solo fondo y texto: sin tarjetas, líneas ni iconos en la lista.
- Márgenes fijos amplios arriba/abajo/lados para no solaparse con las barras del sistema.
- Buscador oculto con gesto horizontal y transición suave.
- **Favoritos** desde Ajustes → Aplicaciones (sin long-press sobre apps).
- Fecha / Hora / Batería:
  - Lateral: columna vertical (90°), fecha estilo «MAR, 24 NOV», batería con punto verde al cargar.
  - Lateral invertido.
  - Superior: bloque arriba alineado a la izquierda, apps debajo.
- Tamaño de texto con rango amplio (14–44 sp).
- Tipos de letra: Sans, Light, Medium, Condensed, Serif, Mono.
- Grosor normal / negrita.
- Pulsación larga en cualquier zona de la pantalla → Ajustes.
- Menú de ajustes minimalista monocromo.
- Preferencias persistentes. applicationId: com.minimal.launcher.

## Versión
- versionName: **1.2**
- versionCode: **5**

## Compilar
```bash
gradle --no-daemon assembleDebug
```
