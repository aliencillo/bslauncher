# BSLauncher 1.2

Launcher Android minimalista (Android 10+, API 29).

- HOME y LAUNCHER con icono propio.
- Fondo y texto configurables, incluido negro puro para ambos.
- Interfaz de solo fondo y texto: sin tarjetas, líneas decorativas, iconos en la lista ni contador.
- Buscador oculto; gesto horizontal con transición suave, foco y teclado al entrar, cierre suave al volver.
- Lista de aplicaciones instaladas con lanzamiento directo.
- **Favoritos**: se configuran desde Ajustes → Aplicaciones (sin usar pulsación larga).
  - Opción **Mostrar todos / Mostrar favoritos**.
  - Lista de todas las apps con casillas para marcar/desmarcar favoritos.
  - La selección se guarda aunque se cierre la aplicación.
- Tres disposiciones: Lateral (bloque horizontal a la derecha), Lateral invertido 180° y Superior (hora grande, fecha completa en español y batería en filas alineadas a la izquierda).
- Fecha compacta en lateral: día/mes y abreviatura del día de la semana.
- Batería real, con punto verde mientras carga y actualización automática.
- Tamaño de texto, negrita, separación, anchura de columna y márgenes configurables.
- Reloj, fecha y batería ocultables por separado; barra de estado oculta por defecto.
- Preferencias persistentes (colores, disposición, tamaños, favoritos, etc.).
- Compatibilidad de actualización mantenida (mismo `applicationId`: `com.minimal.launcher`).
- Rotación de pantalla admitida.

## Versión
- versionName: **1.2**
- versionCode: **3**
- applicationId: `com.minimal.launcher` (sin cambios)

## Compilar
JDK 17, Android SDK Platform 35 y Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.
